#!/usr/bin/env python
#coding=utf-8

# See https://developer.skype.com/wiki/Skype4Py/examples/s4p_chatmessages_py
#     http://skype4py.sourceforge.net/doc/html/
# (Ctrl-C and Ctrl-V) by trydofor@gmail.com

import Skype4Py
import re
import sys
import datetime
import os

skype = Skype4Py.Skype()


def SaveSkypeLog(minDatetime,maxDatetime):
    logdir = minDatetime.strftime('%Y-%m-%d')+'-'+ \
             maxDatetime.strftime('%Y-%m-%d')
    if not os.path.isdir(logdir):
        os.mkdir(logdir)

    print 'get log between:'+logdir
    print('*'*64)
    print 'Connecting to Skype..'

    skype.OnAttachmentStatus = OnAttach
    skype.Attach()

    for chat in skype.Chats:
        print chat.Type +'('+ str(len(chat.Messages))+') '
        filename = chat.Type + chat.Name
        filename = re.sub('\W+','_',filename)
        f = None
        try:
            for mess in chat.Messages[::-1]:
                if mess.Datetime < minDatetime:
                    continue
                if mess.Datetime > maxDatetime:
                    continue

                if f == None:
                    fn = logdir+'/'+filename+'.htm'
                    if os.path.isfile(fn):
                        f = open(fn,'a+')
                    else:
                        f = open(fn,'w')
                        f.write('<meta http-equiv="content-type" \
                                 content="text/html; charset=utf-8"/>')
                        f.write('<title>')
                        f.write(TextEscape(chat.FriendlyName))
                        f.write('</title>')

                fromw = mess.FromHandle
                tlen = len(fromw)
                step = tlen/3
                rv = 0
                for x in fromw[0:step]:
                    rv = rv + ord(x)
                gv = 0
                for x in fromw[step:step*2]:
                    gv = gv + ord(x)
                bv = 0
                for x in fromw[step*2:]:
                    bv = bv + ord(x)

                f.write('<dt style="background-color:rgb('+str(rv%255) \
                    +','+str(gv%255)+','+str(bv%255)+')">')
                f.write(TextEscape(mess.FromDisplayName))
                f.write('[')
                f.write(TextEscape(fromw))
                f.write('] - ')
                f.write(mess.Datetime.strftime('%Y-%m-%d %H:%M:%S'))
                f.write('</dt>')
                f.write('<dd><pre>')
                f.write(TextEscape(mess.Body))
                f.write('</pre></dd>\n')
        finally:
            if f != None:
                f.close()


def OnAttach(status):
    print 'status: ' + skype.Convert.AttachmentStatusToText(status)
    if status == Skype4Py.apiAttachAvailable:
        skype.Attach()

    if status == Skype4Py.apiAttachSuccess:
        print('*'*64)


def TextEscape(text):
    text = text.encode('utf-8')
    text = text.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
    return text


def ShowHelp():
    print '''
    输入两个日期参数,格式为 yyyy-mm-dd
    用来获得两日期(包括)直接的log.
    即 mindate <= logdate <= maxdate
    默认值为今天.
    '''

if __name__ == '__main__':
    mdt = datetime.date.today()
    today = datetime.datetime(mdt.year,mdt.month,mdt.day,0,0,0,0)
    if len(sys.argv) == 1:
        SaveSkypeLog(today,today)
    elif len(sys.argv) == 2:
        mdt = datetime.datetime.strptime(sys.argv[1],'%Y-%m-%d')
        mindate = datetime.datetime(mdt.year,mdt.month,mdt.day,0,0,0,0)
        SaveSkypeLog(mindate,today)
    elif len(sys.argv) == 3:
        mdt = datetime.datetime.strptime(sys.argv[1],'%Y-%m-%d')
        mindate = datetime.datetime(mdt.year,mdt.month,mdt.day,0,0,0,0)
        mdt = datetime.datetime.strptime(sys.argv[2],'%Y-%m-%d')
        maxdate = datetime.datetime(mdt.year,mdt.month,mdt.day,0,0,0,0)
        SaveSkypeLog(mindate,maxdate)
    else:
        ShowHelp()