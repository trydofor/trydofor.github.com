#!/usr/bin/env python
#coding=utf-8

# See https://developer.skype.com/wiki/Skype4Py/examples/s4p_chatmessages_py
#     http://skype4py.sourceforge.net/doc/html/
# (Ctrl-C and Ctrl-V) by trydofor@gmail.com

import Skype4Py
import re
import datetime
import os

skype = Skype4Py.Skype()
mescnt = 0


def OnAttach(status):
    print 'status: ' + skype.Convert.AttachmentStatusToText(status)
    if status == Skype4Py.apiAttachAvailable:
        skype.Attach()

    if status == Skype4Py.apiAttachSuccess:
        print('*'*64)


def TextEscape(text):
    text = text.encode('utf-8')
    text = text.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
    return text


def OnMessageStatus(mess, Status):
    maxDatetime = datetime.date.today()
    logdir = maxDatetime.strftime('%Y-%m-%d')
    if not os.path.isdir(logdir):
        os.mkdir(logdir)

    global mescnt
    chat = mess.Chat
    mescnt = mescnt+1
    print 'message count:'+str(mescnt)
    filename = chat.Type + chat.Name
    filename = re.sub('\W+','_',filename)
    f = None
    try:
        fn = logdir+'/'+filename+'.htm'
        if os.path.isfile(fn):
            f = open(fn,'a+')
        else:
            f = open(fn,'w')
            f.write('<meta http-equiv="content-type" \
                     content="text/html; charset=utf-8"/>')
            f.write('<title>')
            f.write(TextEscape(chat.FriendlyName))
            f.write('</title>')

        fromw = mess.FromHandle
        tlen = len(fromw)
        step = tlen/3
        rv = 0
        for x in fromw[0:step]:
            rv = rv + ord(x)
        gv = 0
        for x in fromw[step:step*2]:
            gv = gv + ord(x)
        bv = 0
        for x in fromw[step*2:]:
            bv = bv + ord(x)

        f.write('<dt style="background-color:rgb('+str(rv%255) \
            +','+str(gv%255)+','+str(bv%255)+')">')
        f.write(TextEscape(mess.FromDisplayName))
        f.write('[')
        f.write(TextEscape(fromw))
        f.write('] - ')
        f.write(mess.Datetime.strftime('%Y-%m-%d %H:%M:%S'))
        f.write('</dt>')
        f.write('<dd><pre>')
        f.write(TextEscape(mess.Body))
        f.write('</pre></dd>\n')
    finally:
        if f != None:
            f.close()


if __name__ == '__main__':

    skype.OnAttachmentStatus = OnAttach
    skype.OnMessageStatus = OnMessageStatus

    print('*'*64)
    print 'Connecting to Skype..'
    skype.Attach()

    # --------------------------------
    # Looping until user types 'exit'
    Cmd = ''
    while not Cmd == 'exit':
        Cmd = raw_input('')
