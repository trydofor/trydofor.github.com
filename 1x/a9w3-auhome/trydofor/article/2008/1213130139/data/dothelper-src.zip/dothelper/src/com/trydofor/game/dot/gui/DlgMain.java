package com.trydofor.game.dot.gui;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseTrackAdapter;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.TabItem;
import org.eclipse.swt.widgets.Text;

import com.cloudgarden.resource.SWTResourceManager;
import com.trydofor.game.dot.DotHelper;
import com.trydofor.game.dot.biz.GameClient;
import com.trydofor.game.dot.udt.ChatItem;
import com.trydofor.game.dot.udt.DotMap;
import com.trydofor.game.dot.udt.DotUser;
import com.trydofor.game.dot.udt.GameContext;
import com.trydofor.game.dot.udt.Magic;
import com.trydofor.game.dot.udt.MapCity;
import com.trydofor.game.dot.udt.MapUser;
import com.trydofor.game.dot.udt.SysInfo;
import com.trydofor.game.dot.udt.UserConf;

public class DlgMain extends org.eclipse.swt.widgets.Dialog {

	private static final Logger logger  = Logger.getLogger(DlgMain.class);

	private final Font font = new Font(Display.getDefault(), "simsun", 9,SWT.NORMAL);
	private final Color colorPink       = new Color(Display.getDefault(),   255, 192, 203); // 沼
	private final Color colorTomato     = new Color(Display.getDefault(), 255, 99, 71); // 土
	private final Color colorLightGreen = new Color(Display.getDefault(), 128, 255, 128); // 草
	private final Color colorSlateBlue  = new Color(Display.getDefault(), 106, 90, 205); //水
	private final Color colorGold       = new Color(Display.getDefault(), 255, 215, 0); //沙
	private final Color colorWhite		= new Color(Display.getDefault(), 255, 255, 255); // 雪
	private final Color colorGreen		= new Color(Display.getDefault(), 0, 128, 0);// 林
	private final Color colorBlack		= new Color(Display.getDefault(), 0, 0, 0); // 城
	private final Color colorGray		= new Color(Display.getDefault(), 128, 128, 128); //镇
	private final Color colorRed		= new Color(Display.getDefault(), 255, 0, 0); //自己
	
	private GameClient	  mGameClient = null;
	private DotMap 		  mDotMap = null; 
	private Map 		  mGameClientMap = new HashMap();
	private Map 		  mMapCell = new HashMap();
	private long  		  refreshCount = 0;
	private boolean       isConfModified = false;
	

	private Button btnLogin;
	private Button btnLogout;
	private Button btnMapDown;
	private Button btnMapLeft;
	private Button btnMapRight;
	private Button btnMapUp;
	private Text txtFightRestPurify;
	private Button chkFightRestBag;
	private Button chkFightRestMp;
	private Button chkFightRestHp;
	private Button chkFightRestPurify;
	private Button btnRelogin;
	private Button btnRoleChatSnd;
	private Button chkMapGrass;
	private Button chkMapLand;
	private Button chkMapMarsh;
	private Button chkMapSand;
	private Button chkMapSnow;
	private Button chkMapWater;
	private Button chkMapWoods;
	private Button rdoMapHold;
	private Button rdoMapRandom;

	private Group grpMapCtrl;
	private Group grpRoleInfo;

	private Label lblBagVal;
	private Label lblDemonVal;
	private Label lblExpVal;
	private Label lblHpVal;
	private Label lblKilledVal;
	private Label lblLevelVal;
	private Label lblMoneyVal;
	private Label lblMpVal;
	
	private Label lblMapCellTip;
	private Label lblMapPos;
	private Label lblRcvKbpsVal;
	private Label lblRcvKbVal;
	private Label lblSndKbpsVal;
	private Label lblSndKbVal;
	private List lstDotUsers;
	private List lstMapUser;
	private Shell dialogShell;
	private StyledText txtRoleChatRcv;
	private TabFolder tfDetail;
	private TabItem tiBag;
	private TabItem tiCity;
	private TabItem tiFight;
	private TabItem tiMap;
	private TabItem tiRole;
	private Text txtRoleChatSnd;
	private Text txtFightRestBag;
	private List lstMagicHave;
	private Button chkFightRestPetHp;
	private Text txtFightRestHp;
	private Text txtFightRestMp;
	private Text txtFightRepair;
	private List lstMagicSeq;

	private Label lblSecPer;
	private Label lblKillPer;
	private Label lblCityPer;
	private Label lblOnlineTime;
	private Label lblKillTime;
	private Label lblCityTime;

	private Text txtFightRestPetHp;

	private Text txtLoginIdle;

	private Text txtCityIdle;

	private Text txtFightIdle;

	private Text txtAttackIdle;

	public DlgMain(Shell parent, int style) {
		super(parent, style);
	}
	
	public void open() {
		try {
			
			Shell parent = getParent();
			dialogShell = new Shell(parent, SWT.DIALOG_TRIM | SWT.APPLICATION_MODAL | SWT.MIN |SWT.RESIZE);

				{
					//Register as a resource user - SWTResourceManager will
					//handle the obtaining and disposing of resources
					SWTResourceManager.registerResourceUser(dialogShell);
				}
			dialogShell.setLayout(null);
			dialogShell.layout();
			dialogShell.setFont(font);
			dialogShell.setImage(new Image(Display.getDefault(), "./res/img/icon.gif"));
			dialogShell.setText("dothelper v1.0");

			//////////////////////////////////////////////
			{
				Composite cpsRoot = new Composite(dialogShell, SWT.NONE);
				cpsRoot.setLayout(null);
				cpsRoot.setBounds(0, 0, 640, 340);
				{
					tfDetail = new TabFolder(cpsRoot, SWT.NONE);
					tfDetail.setBounds(165, 5, 470, 330);
					tfDetail.addSelectionListener(new SelectionAdapter() {
						public void widgetSelected(SelectionEvent evt) {
							tfDetailWidgetSelected(evt);
						}
					});
					{
						tiRole = new TabItem(tfDetail, SWT.NONE);
						tiRole.setText("\u4eba\u7269");
						{
							Composite cpsRole = new Composite(tfDetail, SWT.NONE);
							tiRole.setControl(cpsRole);
							{
								grpRoleInfo = new Group(cpsRole, SWT.NONE);
								grpRoleInfo.setBounds(5, 5, 450, 70);
								grpRoleInfo.setLayout(null);
								{
									Label lblLevel = new Label(grpRoleInfo, SWT.NONE);
									lblLevel.setText("\u7b49\u7ea7:");
									lblLevel.setBounds(15, 25, 30, 12);
									lblLevel.setFont(font);
								}
								{
									lblLevelVal = new Label(grpRoleInfo, SWT.NONE);
									lblLevelVal.setText("1630/4826");
									lblLevelVal.setBounds(50, 25, 80, 12);
									lblLevelVal.setFont(font);
								}
								{
									Label lblExp = new Label(grpRoleInfo, SWT.NONE);
									lblExp.setText("\u7ecf\u9a8c:");
									lblExp.setBounds(140, 25, 30, 12);
									lblExp.setFont(font);
								}
								{
									lblExpVal = new Label(grpRoleInfo, SWT.NONE);
									lblExpVal.setText("10000/45000");
									lblExpVal.setBounds(170, 25, 80, 12);
									lblExpVal.setFont(font);
								}
								{
									Label lblHp = new Label(grpRoleInfo, SWT.NONE);
									lblHp.setText("\u751f\u547d:");
									lblHp.setBounds(15, 45, 30,12);
								}
								{
									lblHpVal = new Label(grpRoleInfo, SWT.NONE);
									lblHpVal.setText("10000/13000");
									lblHpVal.setBounds(50, 45, 80, 12);
								}
								{
									Label lblMp = new Label(grpRoleInfo, SWT.NONE);
									lblMp.setText("\u9b54\u6cd5:");
									lblMp.setBounds(140, 45, 30,12);
								}
								{
									lblMpVal = new Label(grpRoleInfo, SWT.NONE);
									lblMpVal.setText("500/1000");
									lblMpVal.setBounds(170, 45, 80, 12);
								}

								{
									Label lblMoney = new Label(grpRoleInfo, SWT.NONE);
									lblMoney.setText("\u91d1\u94b1:");
									lblMoney.setBounds(255, 25, 30, 12);
									lblMoney.setFont(font);
								}
								{
									lblMoneyVal = new Label(grpRoleInfo,SWT.NONE);
									lblMoneyVal.setText("1234567");
									lblMoneyVal.setBounds(290, 25, 60, 12);
									lblMoneyVal.setFont(font);
								}
								{
									Label lblKilled = new Label(grpRoleInfo, SWT.NONE);
									lblKilled.setText("\u6740\u602a:");
									lblKilled.setBounds(255, 45, 30, 12);
									lblKilled.setFont(font);
								}
								{
									lblKilledVal = new Label(grpRoleInfo,SWT.NONE);
									lblKilledVal.setText("1723");
									lblKilledVal.setBounds(290, 45, 60, 12);
									lblKilledVal.setFont(font);
								}
								{
									Label lblBag = new Label(grpRoleInfo, SWT.NONE);
									lblBag.setText("\u5305\u88f9:");
									lblBag.setBounds(355, 25, 30, 12);
									lblBag.setFont(font);
								}
								{
									lblBagVal = new Label(grpRoleInfo,SWT.NONE);
									lblBagVal.setText("30/65");
									lblBagVal.setBounds(390, 25, 50, 12);
									lblBagVal.setFont(font);
								}

								{
									Label lblDemon = new Label(grpRoleInfo, SWT.NONE);
									lblDemon.setText("\u9b54\u5316:");
									lblDemon.setBounds(355, 45, 30, 12);
									lblDemon.setFont(font);
								}
								{
									lblDemonVal = new Label(grpRoleInfo, SWT.NONE);
									lblDemonVal.setText("301");
									lblDemonVal.setBounds(390, 45, 50, 12);
									lblDemonVal.setFont(font);
								}

							}
							{
								Group grpRoleChat = new Group(cpsRole, SWT.NONE);
								grpRoleChat.setText("\u804a\u5929\u4fe1\u606f");
								grpRoleChat.setBounds(5, 85, 450, 213);
								{
									txtRoleChatRcv = new StyledText(grpRoleChat, SWT.V_SCROLL | SWT.WRAP | SWT.BORDER);
									txtRoleChatRcv.setText("!国聊,/私聊 #组聊 世界聊\n");
									txtRoleChatRcv.setBounds(10, 25, 430, 145);
									txtRoleChatRcv.setFont(font);
								}
								{
									txtRoleChatSnd = new Text(grpRoleChat, SWT.BORDER);
									txtRoleChatSnd.setText("");
									txtRoleChatSnd.setBounds(10, 180, 370, 20);
									txtRoleChatSnd
										.addKeyListener(new KeyAdapter() {
										public void keyReleased(KeyEvent evt) {
											txtRoleChatSndKeyReleased(evt);
										}
										});
								}
								{
									btnRoleChatSnd = new Button(grpRoleChat, SWT.PUSH | SWT.CENTER);
									btnRoleChatSnd.setText("\u53d1\u9001");
									btnRoleChatSnd.setBounds(400, 180, 40, 20);
									btnRoleChatSnd
										.addSelectionListener(new SelectionAdapter() {
										public void widgetSelected(
											SelectionEvent evt) {
											btnRoleChatSndSelected(evt);
										}
										});
								}
							}
						}
					}
					{
						tiFight = new TabItem(tfDetail, SWT.NONE);
						tiFight.setText("\u6218\u6597");
						{
							Composite cpsFight = new Composite(tfDetail, SWT.NONE);
							tiFight.setControl(cpsFight);
							cpsFight.setLayout(null);
							{
								Group grpFightSetting = new Group(cpsFight, SWT.NONE);
								grpFightSetting.setText("\u6218\u6597\u8bbe\u7f6e");
								grpFightSetting.setBounds(5, 5, 453, 150);

								{
									chkFightRestPurify = new Button(
										grpFightSetting,
										SWT.CHECK | SWT.LEFT);
									chkFightRestPurify.setText("\u9b54\u5316\u5927\u4e8e");
									chkFightRestPurify.setBounds(15, 20, 70, 20);
									chkFightRestPurify.addMouseListener(new MouseAdapter() {
										public void mouseDown(MouseEvent evt) 
										{
											onChangeFight(chkFightRestPurify,txtFightRestPurify);
										}
										});
								}
								{
									txtFightRestPurify = new Text(
										grpFightSetting,
										SWT.BORDER);
									txtFightRestPurify.setText("300");
									txtFightRestPurify
										.setBounds(90, 20, 40, 18);
									txtFightRestPurify
										.addModifyListener(new ModifyListener() {
										public void modifyText(ModifyEvent evt) {
											onChangeFight(
												null,
												txtFightRestPurify);
										}
										});
								}
								{
									chkFightRestBag = new Button(
										grpFightSetting,
										SWT.CHECK | SWT.LEFT);
									chkFightRestBag
										.setText("\u5305\u88f9\u5927\u4e8e");
									chkFightRestBag.setBounds(15, 40, 70, 20);
									chkFightRestBag.addMouseListener(new MouseAdapter() {
										public void mouseDown(MouseEvent evt) 
										{
											onChangeFight(chkFightRestBag,txtFightRestBag);
										}
										});
								}
								{
									txtFightRestBag = new Text(
										grpFightSetting,
										SWT.BORDER);
									txtFightRestBag.setText("80");
									txtFightRestBag
										.setBounds(90, 40, 30, 18);
									txtFightRestBag
									.addModifyListener(new ModifyListener() {
									public void modifyText(ModifyEvent evt) {
										onChangeFight(
											null,
											txtFightRestBag);
									}
									});
								}
								{
									Label label1 = new Label(grpFightSetting, SWT.NONE);
									label1.setText("%");
									label1.setBounds(120, 42, 10, 20);
								}
								{
									chkFightRestHp = new Button(grpFightSetting, SWT.CHECK
										| SWT.LEFT);
									chkFightRestHp
										.setText("\u751f\u547d\u5c0f\u4e8e");
									chkFightRestHp.setBounds(15, 60, 70, 20);
									chkFightRestHp.addMouseListener(new MouseAdapter() {
										public void mouseDown(MouseEvent evt) 
										{
											onChangeFight(chkFightRestHp,txtFightRestHp);
										}
										});
								}
								{
									txtFightRestHp = new Text(
										grpFightSetting,
										SWT.BORDER);
									txtFightRestHp.setText("30");
									txtFightRestHp
										.setBounds(90, 60, 30, 18);
									txtFightRestHp
									.addModifyListener(new ModifyListener() {
									public void modifyText(ModifyEvent evt) {
										onChangeFight(
											null,
											txtFightRestHp);
									}
									});
								}
								{
									Label label1 = new Label(grpFightSetting, SWT.NONE);
									label1.setText("%");
									label1.setBounds(120, 62, 10, 20);
								}
								{
									chkFightRestMp = new Button(grpFightSetting, SWT.CHECK
										| SWT.LEFT);
									chkFightRestMp
										.setText("\u9b54\u6cd5\u5c0f\u4e8e");
									chkFightRestMp.setBounds(15, 80, 70, 20);
									chkFightRestMp.addMouseListener(new MouseAdapter() {
										public void mouseDown(MouseEvent evt) 
										{
											onChangeFight(chkFightRestMp,txtFightRestMp);
										}
										});
								}
								{
									txtFightRestMp = new Text(
										grpFightSetting,
										SWT.BORDER);
									txtFightRestMp.setText("30");
									txtFightRestMp
										.setBounds(90, 80, 30, 18);
									txtFightRestMp
									.addModifyListener(new ModifyListener() {
									public void modifyText(ModifyEvent evt) {
										onChangeFight(
											null,
											txtFightRestMp);
									}
									});
								}

								{
									Label label1 = new Label(grpFightSetting, SWT.NONE);
									label1.setText("%");
									label1.setBounds(120, 82, 10, 20);
								}

								
								{
									chkFightRestPetHp = new Button(grpFightSetting, SWT.CHECK
										| SWT.LEFT);
									chkFightRestPetHp.setText("\u5ba0\u8840\u5c0f\u4e8e");
									chkFightRestPetHp.setBounds(15, 100, 70, 20);
								}
								{
									txtFightRestPetHp = new Text(
										grpFightSetting,
										SWT.BORDER);
									txtFightRestPetHp.setText("30");
									txtFightRestPetHp
										.setBounds(90, 100, 30, 18);
								}
								{
									Label label1 = new Label(grpFightSetting, SWT.NONE);
									label1.setText("%");
									label1.setBounds(120, 102, 10, 20);
								}
								
								
								{
									Label label1 = new Label(grpFightSetting, SWT.NONE);
									label1.setText("\u4fee\u7406\u88c5\u5907,\u6bcf");
									label1.setBounds(15, 122, 70, 20);
								}
								{
									txtFightRepair = new Text(
										grpFightSetting,
										SWT.BORDER);
									txtFightRepair.setText("30");
									txtFightRepair
										.setBounds(90, 120, 30, 18);
									txtFightRepair
									.addModifyListener(new ModifyListener() {
									public void modifyText(ModifyEvent evt) {
										onChangeFight(
											null,
											txtFightRepair);
									}
									});
								}
								{
									Label label1 = new Label(grpFightSetting, SWT.NONE);
									label1.setText("怪");
									label1.setBounds(120, 122, 15, 20);
								}
								
								{
									lstMagicHave = new List(
										grpFightSetting,
										SWT.BORDER | SWT.V_SCROLL);
									lstMagicHave.setBounds(150, 20, 130, 70);
								}
								{
									Button btnMagicIn = new Button(
										grpFightSetting,
										SWT.PUSH | SWT.CENTER);
									btnMagicIn.setText("\u2192");
									btnMagicIn.setBounds(287, 20, 16, 16);
									btnMagicIn.addMouseListener(new MouseAdapter() {
										public void mouseDown(MouseEvent evt) {
											onChangeMagic(1);
										}
										});
								}
								{
									Button btnMagicOut = new Button(
										grpFightSetting,
										SWT.PUSH | SWT.CENTER);
									btnMagicOut.setText("\u2190");
									btnMagicOut.setBounds(287, 37, 16, 16);
									btnMagicOut.addMouseListener(new MouseAdapter() {
										public void mouseDown(MouseEvent evt) {
											onChangeMagic(2);
										}
										});
								}
								{
									Button btnMagicUp = new Button(
										grpFightSetting,
										SWT.PUSH | SWT.CENTER);
									btnMagicUp.setText("\u2191");
									btnMagicUp.setBounds(287, 59, 16, 16);
									btnMagicUp.addMouseListener(new MouseAdapter() {
										public void mouseDown(MouseEvent evt) {
											onChangeMagic(3);
										}
										});
								}
								{
									Button btnMagicDown = new Button(
										grpFightSetting,
										SWT.PUSH | SWT.CENTER);
									btnMagicDown.setText("\u2193");
									btnMagicDown.setBounds(287, 76, 16, 16);
									btnMagicDown.addMouseListener(new MouseAdapter() {
										public void mouseDown(MouseEvent evt) {
											onChangeMagic(4);
										}
										});
								}
								{
									lstMagicSeq = new List(
										grpFightSetting,
										SWT.BORDER | SWT.V_SCROLL);
									lstMagicSeq.setBounds(310, 20, 130, 70);
								}
								
								{
									Label label1 = new Label(grpFightSetting, SWT.NONE);
									label1.setText("\u767b\u5f55\u95f4\u9694:");
									label1.setBounds(150, 100, 60, 20);
								}
								{
									txtLoginIdle = new Text(
										grpFightSetting,
										SWT.BORDER);
									txtLoginIdle.setText("30");
									txtLoginIdle
										.setBounds(210, 98, 30, 18);
									txtLoginIdle
									.addModifyListener(new ModifyListener() {
									public void modifyText(ModifyEvent evt) {
										mGameClient.getUserConf().setLoginIdle(Integer.parseInt(txtLoginIdle.getText()));
										isConfModified = true;
									}
									});
								}
								{
									Label label1 = new Label(grpFightSetting, SWT.NONE);
									label1.setText("S");
									label1.setBounds(245, 100, 16, 16);
								}
								{
									Label label1 = new Label(grpFightSetting, SWT.NONE);
									label1.setText("\u56de\u57ce\u95f4\u9694:");
									label1.setBounds(150, 120, 60, 20);
								}
								{
									txtCityIdle = new Text(
										grpFightSetting,
										SWT.BORDER);
									txtCityIdle.setText("30");
									txtCityIdle
										.setBounds(210, 118, 30, 18);
									txtCityIdle
									.addModifyListener(new ModifyListener() {
									public void modifyText(ModifyEvent evt) {
										mGameClient.getUserConf().setCityIdle(Integer.parseInt(txtCityIdle.getText()));
										isConfModified = true;
									}
									});
								}
								{
									Label label1 = new Label(grpFightSetting, SWT.NONE);
									label1.setText("S");
									label1.setBounds(245, 118, 16, 16);
								}
								{
									Label label1 = new Label(grpFightSetting, SWT.NONE);
									label1.setText("\u9047\u602a\u95f4\u9694:");
									label1.setBounds(300, 100, 60, 20);
								}
								{
									txtFightIdle = new Text(
										grpFightSetting,
										SWT.BORDER);
									txtFightIdle.setText("30");
									txtFightIdle
										.setBounds(360, 98, 30, 18);
									txtFightIdle
									.addModifyListener(new ModifyListener() {
									public void modifyText(ModifyEvent evt) {
										mGameClient.getUserConf().setFightIdle(Integer.parseInt(txtFightIdle.getText()));
										isConfModified = true;
									}
									});
								}
								{
									Label label1 = new Label(grpFightSetting, SWT.NONE);
									label1.setText("S");
									label1.setBounds(395, 100, 16, 16);
								}
								{
									Label label1 = new Label(grpFightSetting, SWT.NONE);
									label1.setText("\u653b\u51fb\u95f4\u9694:");
									label1.setBounds(300, 120, 60, 20);
								}
								{
									txtAttackIdle = new Text(
										grpFightSetting,
										SWT.BORDER);
									txtAttackIdle.setText("30");
									txtAttackIdle
										.setBounds(360, 118, 30, 18);
									txtAttackIdle
									.addModifyListener(new ModifyListener() {
									public void modifyText(ModifyEvent evt) {
										mGameClient.getUserConf().setAttackIdle(Integer.parseInt(txtAttackIdle.getText()));
										isConfModified = true;
									}
									});
								}
								{
									Label label1 = new Label(grpFightSetting, SWT.NONE);
									label1.setText("MS");
									label1.setBounds(395, 120, 16, 16);
								}
							}
							{
								Group grpFightCtrl = new Group(cpsFight, SWT.NONE);
								grpFightCtrl
									.setText("\u6218\u6597\u63a7\u5236");
								grpFightCtrl.setBounds(5, 240, 453, 60);
								grpFightCtrl.setLayout(null);
								{
									Button btnManualLogin = new Button(
										grpFightCtrl,
										SWT.PUSH | SWT.CENTER);
									btnManualLogin.setText("\u767b\u5f55");
									btnManualLogin.setBounds(70, 25, 40, 20);
									btnManualLogin
										.addMouseListener(new MouseAdapter() {
										public void mouseDown(MouseEvent evt) {
											mGameClient.login();
										}
										});
								}
								{
									Button btnManualFight = new Button(
										grpFightCtrl,
										SWT.PUSH | SWT.CENTER);
									btnManualFight.setText("\u6218\u6597");
									btnManualFight.setBounds(115, 25, 40, 20);
									btnManualFight
									.addMouseListener(new MouseAdapter() {
									public void mouseDown(MouseEvent evt) {
										mGameClient.fight();
									}
									});
								}
								{
									Button btnManualCity = new Button(
										grpFightCtrl,
										SWT.PUSH | SWT.CENTER);
									btnManualCity.setText("\u56de\u57ce");
									btnManualCity.setBounds(160, 25, 40, 20);
									btnManualCity.addMouseListener(new MouseAdapter() {
										public void mouseDown(MouseEvent evt) {
											mGameClient.cityBiz();
										}
										});
								}
								{
									Button btnManualRepair = new Button(
										grpFightCtrl,
										SWT.PUSH | SWT.CENTER);
									btnManualRepair.setText("\u4fee\u7406");
									btnManualRepair.setBounds(205, 25, 40, 20);
									btnManualRepair.addMouseListener(new MouseAdapter() {
										public void mouseDown(MouseEvent evt) {
											mGameClient.repair();
										}
										});
								}
								{
									Button btnManualPause = new Button(
										grpFightCtrl,
										SWT.PUSH | SWT.CENTER);
									btnManualPause.setText("\u6682\u505c"); //暂停
									btnManualPause.setBounds(15, 25, 40, 20);
									btnManualPause.setBackground(colorGold);
									btnManualPause.addMouseListener(new MouseAdapter() {
										public void mouseUp(MouseEvent evt) 
										{
											Button button = (Button)evt.widget;
											String t = button.getText();
											
											if(t.endsWith("\u6682\u505c"))
											{
												mGameClient.setPause(true);
												button.setText("\u7ee7\u7eed"); //继续
											}
											else
											{
												mGameClient.setPause(false);
												button.setText("\u6682\u505c");
											}
										}
										});
								}
							}
							{
								Group grpFightInfo = new Group(cpsFight, SWT.NONE);
								grpFightInfo
									.setText("\u6218\u6597\u7edf\u8ba1");
								grpFightInfo.setBounds(5, 160, 453, 75);
								grpFightInfo.setLayout(null);
								{
									Label label = new Label(grpFightInfo, SWT.NONE);
									label.setBounds(15, 25, 50, 18);
									label.setText("\u5355\u602a\u8017\u65f6:");
								}
								{
									lblSecPer = new Label(grpFightInfo, SWT.NONE);
									lblSecPer.setBounds(70, 25, 50, 18);
									lblSecPer.setText("20 S");
								}
								{
									Label label = new Label(grpFightInfo, SWT.NONE);
									label.setBounds(150, 25, 50, 18);
									label.setText("\u5355\u602a\u65a9\u6570:");
								}
								{
									lblKillPer = new Label(grpFightInfo, SWT.NONE);
									lblKillPer.setBounds(205, 25, 50, 18);
									lblKillPer.setText("20");
								}
								{
									Label label = new Label(grpFightInfo, SWT.NONE);
									label.setBounds(285, 25, 50, 18);
									label.setText("\u56de\u57ce\u602a\u6570:");
								}
								{
									lblCityPer = new Label(grpFightInfo, SWT.NONE);
									lblCityPer.setBounds(340, 25, 50, 18);
									lblCityPer.setText("5");
								}
								{
									Label label = new Label(grpFightInfo, SWT.NONE);
									label.setBounds(15, 50, 50, 18);
									label.setText("\u5728\u7ebf\u65f6\u957f:");
								}
								{
									lblOnlineTime = new Label(grpFightInfo, SWT.NONE);
									lblOnlineTime.setBounds(70, 50, 80, 18);
									lblOnlineTime.setText("00:00:00");
								}
								{
									Label label = new Label(grpFightInfo, SWT.NONE);
									label.setBounds(150, 50, 50, 18);
									label.setText("\u6740\u602a\u65f6\u957f:");
								}
								{
									lblKillTime = new Label(grpFightInfo, SWT.NONE);
									lblKillTime.setBounds(205, 50, 80, 18);
									lblKillTime.setText("00:00:00");
								}
								{
									Label label = new Label(grpFightInfo, SWT.NONE);
									label.setBounds(285, 50, 50, 18);
									label.setText("\u56de\u57ce\u65f6\u957f:");
								}
								{
									lblCityTime = new Label(grpFightInfo, SWT.NONE);
									lblCityTime.setBounds(340, 50, 80, 18);
									lblCityTime.setText("00:00:00");
								}
							}
						}
					}
					
					{
						tiBag = new TabItem(tfDetail, SWT.NONE);
						tiBag.setText("\u7269\u54c1");
					}

					{
						tiCity = new TabItem(tfDetail, SWT.NONE);
						tiCity.setText("\u57ce\u5e02");
					}

					{
						tiMap = new TabItem(tfDetail, SWT.NONE);
						tiMap.setText("\u5730\u56fe");
						{
							Composite cpsMap = new Composite(tfDetail, SWT.NONE);
							tiMap.setControl(cpsMap);
							cpsMap.setLayout(null);
							{
								lblMapCellTip = new Label(cpsMap,SWT.BORDER);
								lblMapCellTip.setText("Tip");
								lblMapCellTip.setBounds(275, 10, 180, 95);
								lblMapCellTip.setVisible(false);
								
								Group grpNowMap = new Group(cpsMap, SWT.NONE);
								grpNowMap.setLayout(null);
								grpNowMap.setText("\u5f53\u524d\u5730\u56fe");
								grpNowMap.setBounds(5, 5, 260, 290);
								
								//
								// draw map sells
								for(int y=0;y<24;y++)
								for(int x=0;x<24;x++)
								{
									String key = "ms-"+x+","+y;
									Label cell = new Label(grpNowMap, SWT.NONE);
									cell.setBounds(10+10*x, 20+10*y, 10, 10);
									cell.setText("             "+key);
									cell.addMouseListener(new MouseAdapter() {
										public void mouseDown(MouseEvent evt)
										{
											onClickMapCell(evt);
										}
									});
	
									cell.addMouseTrackListener(new MouseTrackAdapter()
									{
										public void mouseEnter(MouseEvent evt)
										{
											onHoverMapCell(evt,true);
										}
										public void mouseExit(MouseEvent evt) {
											onHoverMapCell(evt,false);
										}
									});
									
									mMapCell.put(key, cell);
								}
								
								{
									btnMapLeft = new Button(grpNowMap, SWT.PUSH| SWT.CENTER);
									btnMapLeft.setText("\u2190");
									btnMapLeft.setBounds(10, 265, 18, 18);
									btnMapLeft.setAlignment(SWT.CENTER);
									btnMapLeft.addMouseListener(new MouseAdapter() 
									{
										public void mouseDown(MouseEvent evt) {
											onMapMove(DotMap.MOVE_LEFT);
										}
										});
								}
								{
									btnMapUp = new Button(grpNowMap, SWT.PUSH| SWT.CENTER);
									btnMapUp.setText("\u2191");
									btnMapUp.setBounds(30, 265, 18, 18);
									btnMapUp.setAlignment(SWT.CENTER);
									btnMapUp.addMouseListener(new MouseAdapter() 
									{
										public void mouseDown(MouseEvent evt) {
											onMapMove(DotMap.MOVE_UP);
										}
										});
								}
								{
									btnMapDown = new Button(grpNowMap, SWT.PUSH| SWT.CENTER);
									btnMapDown.setText("\u2193");
									btnMapDown.setBounds(50, 265, 18, 18);
									btnMapDown.setAlignment(SWT.CENTER);
									btnMapDown.addMouseListener(new MouseAdapter() 
									{
										public void mouseDown(MouseEvent evt) {
											onMapMove(DotMap.MOVE_DOWN);
										}
										});
								}
								{
									btnMapRight = new Button(grpNowMap, SWT.PUSH| SWT.CENTER);
									btnMapRight.setText("\u2192");
									btnMapRight.setBounds(70, 265, 18, 18);
									btnMapRight.setAlignment(SWT.CENTER);
									btnMapRight.addMouseListener(new MouseAdapter() 
									{
										public void mouseDown(MouseEvent evt) {
											onMapMove(DotMap.MOVE_RIGHT);
										}
										});
								}
								{
									Label lblMapEgLand = new Label(grpNowMap,SWT.NONE);
									lblMapEgLand.setText("\u571f");
									lblMapEgLand.setFont(font);
									lblMapEgLand.setBackground(colorTomato);
									lblMapEgLand.setBounds(100, 265, 15, 18);
									lblMapEgLand.setAlignment(SWT.CENTER);

								}
								{
								    Label lblMapEgWater = new Label(grpNowMap,SWT.NONE);
									lblMapEgWater.setText("\u6c34");
									lblMapEgWater.setFont(font);
									lblMapEgWater.setBackground(colorSlateBlue);
									lblMapEgWater.setBounds(115, 265, 15, 18);
								    lblMapEgWater.setAlignment(SWT.CENTER);
								}

								{
								    Label lblMapEgGrass = new Label(grpNowMap,SWT.NONE);
									lblMapEgGrass.setText("\u8349");
									lblMapEgGrass.setFont(font);
									lblMapEgGrass.setBackground(colorLightGreen);
									lblMapEgGrass.setBounds(130, 265, 15, 18);
								    lblMapEgGrass.setAlignment(SWT.CENTER);
								}

								{
								    Label lblMapEgSand = new Label(grpNowMap,SWT.NONE);
									lblMapEgSand.setText("\u6c99");
									lblMapEgSand.setFont(font);
									lblMapEgSand.setBackground(colorGold);
									lblMapEgSand.setBounds(145, 265, 15, 18);
								    lblMapEgSand.setAlignment(SWT.CENTER);
								}

								{
								    Label lblMapEgSnow = new Label(grpNowMap,SWT.NONE);
									lblMapEgSnow.setText("\u96ea");
									lblMapEgSnow.setFont(font);
									lblMapEgSnow.setBackground(colorWhite);
									lblMapEgSnow.setBounds(160, 265, 15, 18);
								    lblMapEgSnow.setAlignment(SWT.CENTER);
								}

								{
								    Label lblMapEgMarsh = new Label(grpNowMap,SWT.NONE);
									lblMapEgMarsh.setText("\u6cbc");
									lblMapEgMarsh.setFont(font);
									lblMapEgMarsh.setBackground(colorPink);
									lblMapEgMarsh.setBounds(175, 265, 15, 18);
								    lblMapEgMarsh.setAlignment(SWT.CENTER);
								}

								{
								    Label lblMapEgWoods = new Label(grpNowMap,SWT.NONE);
									lblMapEgWoods.setText("\u6797");
									lblMapEgWoods.setFont(font);
									lblMapEgWoods.setBackground(colorGreen);
									lblMapEgWoods.setBounds(190, 265, 15, 18);
								    lblMapEgWoods.setAlignment(SWT.CENTER);
								}

								{
								    Label lblMapEgTown = new Label(grpNowMap,SWT.NONE);
									lblMapEgTown.setText("\u9547");
									lblMapEgTown.setFont(font);
									lblMapEgTown.setBackground(colorGray);
									lblMapEgTown.setBounds(205, 265, 15, 18);
								    lblMapEgTown.setAlignment(SWT.CENTER);
								}

								{
								    Label lblMapEgCity = new Label(grpNowMap,SWT.NONE);
									lblMapEgCity.setText("\u57ce");
									lblMapEgCity.setFont(font);
									lblMapEgCity.setForeground(colorWhite);
									lblMapEgCity.setBackground(colorBlack);
									lblMapEgCity.setBounds(220, 265, 15, 18);
								    lblMapEgCity.setAlignment(SWT.CENTER);
								}
								{
								    Label lblMapEgSelf = new Label(grpNowMap,SWT.NONE);
								    lblMapEgSelf.setText("\u6211");
								    lblMapEgSelf.setFont(font);
								    lblMapEgSelf.setBackground(colorRed);
								    lblMapEgSelf.setBounds(235, 265, 15, 18);
								    lblMapEgSelf.setAlignment(SWT.CENTER);
								}

							}

							{
								grpMapCtrl = new Group(cpsMap, SWT.NONE);
								grpMapCtrl.setLayout(null);
								grpMapCtrl.setText("\u5730\u56fe\u63a7\u5236");
								grpMapCtrl.setBounds(275, 5, 180, 100);

								{ //1
									chkMapWater = new Button(grpMapCtrl, SWT.CHECK
										| SWT.LEFT);
									chkMapWater.setText("\u6c34");
									chkMapWater.setBounds(10, 20, 30, 16);
									chkMapWater.setFont(font);
									chkMapWater
										.addMouseListener(new MouseAdapter() {
											public void mouseUp(MouseEvent evt) {
												onSetMapType();
											}
										});
								}
								{ //2
									chkMapLand = new Button(grpMapCtrl, SWT.CHECK
										| SWT.LEFT);
									chkMapLand.setText("\u571f");
									chkMapLand.setBounds(45, 20, 30, 16);
									chkMapLand.setFont(font);
									chkMapLand.addMouseListener(new MouseAdapter() {
										public void mouseUp(MouseEvent evt) {
											onSetMapType();
										}
										});
								}
								
								{ //3
									chkMapGrass = new Button(grpMapCtrl, SWT.CHECK
										| SWT.LEFT);
									chkMapGrass.setText("\u8349");
									chkMapGrass.setBounds(80, 20, 30, 16);
									chkMapGrass.setFont(font);
									chkMapGrass.addMouseListener(new MouseAdapter() {
										public void mouseUp(MouseEvent evt) {
											onSetMapType();
										}
										});
								}
								
								{ //4
									chkMapSand = new Button(grpMapCtrl, SWT.CHECK
										| SWT.LEFT);
									chkMapSand.setText("\u6c99");
									chkMapSand.setBounds(115, 20, 30, 16);
									chkMapSand.setFont(font);
									chkMapSand.addMouseListener(new MouseAdapter() {
										public void mouseUp(MouseEvent evt) {
											onSetMapType();
										}
										});
								}
								
								{ //5
									chkMapSnow = new Button(grpMapCtrl, SWT.CHECK
										| SWT.LEFT);
									chkMapSnow.setText("\u96ea");
									chkMapSnow.setBounds(10, 40, 30, 16);
									chkMapSnow.setFont(font);
									chkMapSnow.addMouseListener(new MouseAdapter() {
										public void mouseUp(MouseEvent evt) {
											onSetMapType();
										}
										});
								}
								{ //6
									chkMapMarsh = new Button(grpMapCtrl, SWT.CHECK
										| SWT.LEFT);
									chkMapMarsh.setText("\u6cbc");
									chkMapMarsh.setBounds(45, 40, 30, 16);
									chkMapMarsh.setFont(font);
									chkMapMarsh.addMouseListener(new MouseAdapter() {
										public void mouseUp(MouseEvent evt) {
											onSetMapType();
										}
										});
								}
								{ //7
									chkMapWoods = new Button(grpMapCtrl, SWT.CHECK
										| SWT.LEFT);
									chkMapWoods.setText("\u6797");
									chkMapWoods.setBounds(80, 40, 30, 16);
									chkMapWoods.setFont(font);
									chkMapWoods.addMouseListener(new MouseAdapter() {
										public void mouseUp(MouseEvent evt) {
											onSetMapType();
										}
										});
								}
								{
									rdoMapRandom = new Button(
										grpMapCtrl,
										SWT.RADIO | SWT.LEFT);
									rdoMapRandom.setText("\u968f\u673a");
									rdoMapRandom.setBounds(10, 70, 50, 16);
									rdoMapRandom.setFont(font);
									rdoMapRandom.setSelection(true);
									rdoMapRandom.addMouseListener(new MouseAdapter() {
										public void mouseDown(MouseEvent evt) {
											mGameClient.getUserConf().setMapRandom(true);
										}
										});
								}
								{
									rdoMapHold = new Button(grpMapCtrl, SWT.RADIO
										| SWT.LEFT);
									rdoMapHold.setText("\u5b9a\u70b9");
									rdoMapHold.setBounds(60, 70, 50, 16);
									rdoMapHold.setFont(font);
									rdoMapHold.addMouseListener(new MouseAdapter() {
										public void mouseDown(MouseEvent evt) {
											mGameClient.getUserConf().setMapRandom(false);
										}
										});
								}
								{
									lblMapPos = new Label(grpMapCtrl, SWT.NONE);
									lblMapPos.setText("(0,20)");
									lblMapPos.setBounds(110, 70, 60, 16);
									lblMapPos.setFont(font);
								}
							}
							{
								Group grpMapUser = new Group(cpsMap, SWT.NONE);
								grpMapUser.setText("\u5176\u5b83\u73a9\u5bb6");
								grpMapUser.setBounds(275, 115, 180, 180);
								grpMapUser.setLayout(null);
								{
									lstMapUser = new List(grpMapUser, SWT.BORDER | SWT.V_SCROLL);
									lstMapUser.setBounds(10, 20, 160, 150);
								}
							}
						}
					}
				}
				{
					Group grpDotUsers = new Group(cpsRoot, SWT.NONE);
					grpDotUsers.setFont(font);
					grpDotUsers.setText("\u7528\u6237\u64cd\u4f5c");
					grpDotUsers.setBounds(5, 5, 150, 215);
					{
						lstDotUsers = new List(grpDotUsers, SWT.BORDER | SWT.SINGLE | SWT.V_SCROLL);
						lstDotUsers.setBounds(10, 20, 130, 150);
						lstDotUsers.setFont(font);
						lstDotUsers.addSelectionListener(new SelectionAdapter() {
							public void widgetSelected(SelectionEvent evt) {
								lstDotUsersSelected(evt);
							}
						});
					}
					{
						btnLogin = new Button(grpDotUsers, SWT.PUSH | SWT.CENTER);
						btnLogin.setText("\u767b\u5f55");
						btnLogin.setBounds(10, 180, 40, 22);
						btnLogin.setFont(font);
						btnLogin.addSelectionListener(new SelectionAdapter() {
							public void widgetSelected(SelectionEvent evt) {
								btnDengluWidgetSelected(evt);
							}
						});
					}
					{
						btnRelogin = new Button(grpDotUsers, SWT.PUSH | SWT.CENTER);
						btnRelogin.setText("\u91cd\u767b");
						btnRelogin.setBounds(55, 180, 40, 22);
						btnRelogin.setFont(font);
						btnRelogin.addSelectionListener(new SelectionAdapter() {
							public void widgetSelected(SelectionEvent evt) {
								btnChongdengWidgetSelected(evt);
							}
						});
					}
					{
						btnLogout = new Button(grpDotUsers, SWT.PUSH | SWT.CENTER);
						btnLogout.setText("\u767b\u51fa");
						btnLogout.setBounds(100, 180, 40, 22);
						btnLogout.setFont(font);
						btnLogout.addSelectionListener(new SelectionAdapter() {
							public void widgetSelected(SelectionEvent evt) {
								btnDengchuWidgetSelected(evt);
							}
						});
					}
				}
				{
					Group grpSysInfo = new Group(cpsRoot, SWT.NONE);
					grpSysInfo.setText("\u7edf\u8ba1\u4fe1\u606f");
					grpSysInfo.setBounds(5, 230, 150, 105);
					grpSysInfo.setFont(font);

					{
						Label lblRcvKb = new Label(grpSysInfo, SWT.NONE);
						lblRcvKb.setText("\u63a5\u6536:");
						lblRcvKb.setBounds(10, 21, 40, 12);
						lblRcvKb.setFont(font);
					}
					{
						lblRcvKbVal = new Label(grpSysInfo, SWT.NONE);
						lblRcvKbVal.setText("103.3 M");
						lblRcvKbVal.setBounds(50, 21, 90, 12);
						lblRcvKbVal.setFont(font);
					}
					{
						Label lblSndKb = new Label(grpSysInfo, SWT.NONE);
						lblSndKb.setText("\u53d1\u9001:");
						lblSndKb.setBounds(10, 41, 40, 12);
						lblSndKb.setFont(font);
					}

					{
						lblSndKbVal = new Label(grpSysInfo, SWT.NONE);
						lblSndKbVal.setText("23.7 M");
						lblSndKbVal.setBounds(50, 41, 90, 12);
						lblSndKbVal.setFont(font);
					}

					{
						Label lblSndKbps = new Label(grpSysInfo, SWT.NONE);
						lblSndKbps.setText("\u79d2\u5165:");
						lblSndKbps.setBounds(10, 61, 40, 12);
						lblSndKbps.setFont(font);
					}
					{
						lblSndKbpsVal = new Label(grpSysInfo, SWT.NONE);
						lblSndKbpsVal.setText("10.6 K");
						lblSndKbpsVal.setBounds(50, 61, 90, 12);
						lblSndKbpsVal.setFont(font);
					}
					{
						Label lblRcvKbps = new Label(grpSysInfo, SWT.NONE);
						lblRcvKbps.setText("\u79d2\u51fa:");
						lblRcvKbps.setBounds(10, 81, 40, 12);
						lblRcvKbps.setFont(font);
					}
					{
						lblRcvKbpsVal = new Label(grpSysInfo, SWT.NONE);
						lblRcvKbpsVal.setText("0.6 K");
						lblRcvKbpsVal.setBounds(50, 81, 90, 12);
						lblRcvKbpsVal.setFont(font);
					}

				}
			}

			//////////////////////////////////////////////
			dialogShell.pack();
			dialogShell.setSize(650, 370);
			int h = parent.getClientArea().height - dialogShell.getBounds().height;
			int w = parent.getClientArea().width  - dialogShell.getBounds().width;
			dialogShell.setLocation((int)w/2, (int)h/2);
			//
			dialogShell.open();
			Display display = dialogShell.getDisplay();
			
			Runnable timer = new Runnable()
			{
				public void run() 
				{
					if(mGameClient == null)
					{
						initData();
					}
					else
					{
						refreshData();
					}
				}
			};
			
			while (!dialogShell.isDisposed()) 
			{
				if (!display.readAndDispatch())
					display.sleep();
				else
					display.timerExec(500, timer);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			System.exit(0);
		}
	}
	
	private void initData()
	{
		// init users list
		mGameClientMap = DotHelper.getGameClientMap();
		for (Iterator iter = mGameClientMap.values().iterator(); iter.hasNext();)
		{
			GameClient gc = (GameClient) iter.next();
			if(mGameClient == null)
			{
				mGameClient = gc;
				mDotMap = gc.getDotMap();
			}
			
			lstDotUsers.add("[新] "+gc.getDotUser().getLoginId());
		}
		lstDotUsers.select(0);
		
		isConfModified = true;
	}
	
	
	/////
	private void refreshConf()
	{
		if(!isConfModified) return;
		
		UserConf uc = mGameClient.getUserConf();
		if(uc != null)
		{
			int[] types = uc.getMapType();
			if(types != null && types.length>0)
			{
				chkMapGrass.setSelection(false);
				chkMapLand.setSelection(false);
				chkMapMarsh.setSelection(false);
				chkMapSand.setSelection(false);
				chkMapSnow.setSelection(false);
				chkMapWater.setSelection(false);
				chkMapWoods.setSelection(false);
	
				
				for (int i = 0; i < types.length; i++)
				{
					if(types[i] == DotMap.TYPE_GRASS) chkMapGrass.setSelection(true);
					else if (types[i] == DotMap.TYPE_LAND) chkMapLand.setSelection(true);
					else if (types[i] == DotMap.TYPE_MARSH) chkMapMarsh.setSelection(true);
					else if (types[i] == DotMap.TYPE_SAND) chkMapSand.setSelection(true);
					else if (types[i] == DotMap.TYPE_SNOW) chkMapSnow.setSelection(true);
					else if (types[i] == DotMap.TYPE_WATER) chkMapWater.setSelection(true);
					else if (types[i] == DotMap.TYPE_WOODS) chkMapWoods.setSelection(true);
				}
			}
		
			///
			if(uc.getRepair()>0)
			{
				txtFightRepair.setText(String.valueOf(uc.getRepair()));
			}
			
			if(uc.getSellBag()>0)
			{
				txtFightRestBag.setText(String.valueOf(uc.getSellBag()));
				chkFightRestBag.setSelection(true);
			}
			else
			{
				chkFightRestBag.setSelection(false);
			}
			
			if(uc.getSleepHp()>0)
			{
				txtFightRestHp.setText(String.valueOf(uc.getSleepHp()));
				chkFightRestHp.setSelection(true);
			}
			else
			{
				chkFightRestHp.setSelection(false);
			}
			
			if(uc.getSleepMp()>0)
			{
				txtFightRestMp.setText(String.valueOf(uc.getSleepMp()));
				chkFightRestMp.setSelection(true);
			}
			else
			{
				chkFightRestMp.setSelection(false);
			}
			
			
			if(uc.getPurify()>0)
			{
				txtFightRestPurify.setText(String.valueOf(uc.getPurify()));
				chkFightRestPurify.setSelection(true);
			}
			else
			{
				chkFightRestPurify.setSelection(false);
			}
			
			chkFightRestPetHp.setEnabled(false);
			txtFightRestPetHp.setEnabled(false);
			
			txtLoginIdle.setText(String.valueOf(uc.getLoginIdle()));
			txtCityIdle.setText(String.valueOf(uc.getCityIdle()));
			txtFightIdle.setText(String.valueOf(uc.getFightIdle()));
			txtAttackIdle.setText(String.valueOf(uc.getAttackIdle()));
		}
		
		Map magics = mGameClient.getGameContext().getMagicMap();
		if(magics != null)
		{
			lstMagicHave.removeAll();
			for (Iterator iter = magics.values().iterator(); iter.hasNext();) 
			{
				Magic m = (Magic) iter.next();
				lstMagicHave.add(m.getName()+"("+m.getMp()+")");
//				System.out.println(">>>>"+m.getId()+":"+m.getName()+":"+m.getMp());
			}
			
			//
			//lstMagicSeq//
			if(uc != null)
			{
				String[] attacks = uc.getAttack();
				lstMagicSeq.removeAll();
				for (int i = 0; i < attacks.length; i++) 
				{
					Magic m = (Magic) magics.get(attacks[i]);
					if(m != null)
					{
						lstMagicSeq.add(m.getName()+"("+m.getMp()+")");
					}
					else
					{
						logger.error("error attack:"+attacks[i]);
					}
				}
			}
		}
		
		chkMapWater.setEnabled(mDotMap.hasType(DotMap.TYPE_WATER));
		chkMapGrass.setEnabled(mDotMap.hasType(DotMap.TYPE_GRASS));
		chkMapLand.setEnabled(mDotMap.hasType(DotMap.TYPE_LAND));
		chkMapMarsh.setEnabled(mDotMap.hasType(DotMap.TYPE_MARSH));
		chkMapSand.setEnabled(mDotMap.hasType(DotMap.TYPE_SAND));
		chkMapSnow.setEnabled(mDotMap.hasType(DotMap.TYPE_SNOW));
		chkMapWoods.setEnabled(mDotMap.hasType(DotMap.TYPE_WOODS));
		
		boolean isRandom = mGameClient.getUserConf().isMapRandom();
		rdoMapRandom.setSelection(isRandom);
		rdoMapHold.setSelection(!isRandom);
		
		isConfModified = false;
	}
	
	private void refreshUserList()
	{
		String[] items = lstDotUsers.getItems();
		for (int i = 0; i < items.length; i++)
		{
			String loginId = items[i].substring(items[i].indexOf(' '),items[i].length()).trim();
			GameClient gc = (GameClient) mGameClientMap.get(loginId);
			String status = "[错] ";
			switch(gc.getGameContext().getStatus())
			{
				case GameContext.STATUS_INIT :
					status = "[新] ";
					break;
				case GameContext.STATUS_FIGHT :
					status = "[战] ";
					break;
				case GameContext.STATUS_LOGIN :
					status = "[登] ";
					break;
				case GameContext.STATUS_LOGOUT :
					status = "[离] ";
					break;
				case GameContext.STATUS_INCITY :
					status = "[城] ";
					break;
				case GameContext.STATUS_PAUSE :
					status = "[暂] ";
					break;
				case GameContext.STATUS_STOP :
					status = "[停] ";
					break;
				default:
			}
			
			lstDotUsers.setItem(i, status+loginId);
		}
	}
	
	private void refreshSysInfo()
	{
		SysInfo sysInfo = mGameClient.getSysInfo();
		if(sysInfo != null)
		{
			lblSndKbVal.setText(((int)(sysInfo.getSndBytes() / 1000))+" K");
			lblRcvKbVal.setText(((int)(sysInfo.getRcvBytes() / 1000))+" K");
			lblRcvKbpsVal.setText(((int)(sysInfo.getSndBps() / 1000))+" K");
			lblSndKbpsVal.setText(((int)(sysInfo.getRcvBps() / 1000))+" K");
		}
	}
	private void refreshMapTab()
	{
		DotMap dm = mGameClient.getDotMap();
		if(dm != mDotMap)
		{
			mDotMap = dm;
			isConfModified = true;
		}
		if(dm != null)
		{
			for(int y=0;y<24;y++)
			for(int x=0;x<24;x++)
			{
				Label cell = (Label)mMapCell.get("ms-"+x+","+y);
				switch(dm.getMapType(x, y))
				{
					case DotMap.TYPE_CITY:
						cell.setBackground(colorBlack);
						break;
					case DotMap.TYPE_TOWN:
						cell.setBackground(colorGray);
						break;
					case DotMap.TYPE_GRASS:
						cell.setBackground(colorLightGreen);
						break;
					case DotMap.TYPE_WOODS:
						cell.setBackground(colorGreen);
						break;
					case DotMap.TYPE_LAND:
						cell.setBackground(colorTomato);
						break;
					case DotMap.TYPE_MARSH:
						cell.setBackground(colorPink);
						break;
					case DotMap.TYPE_SAND:
						cell.setBackground(colorGold);
						break;
					case DotMap.TYPE_SNOW:
						cell.setBackground(colorWhite);
						break;
					case DotMap.TYPE_WATER:
						cell.setBackground(colorSlateBlue);
						break;
				}
			}
		}
		
		GameContext gc = mGameClient.getGameContext();
		if(gc != null)
		{
			int userx = gc.getUserX()-dm.getMapX();
			int usery = gc.getUserY()-dm.getMapY();
			Label cell = (Label)mMapCell.get("ms-"+userx+","+usery);
			cell.setBackground(colorRed);
			
			lblMapPos.setText("("+gc.getUserX()+","+gc.getUserY()+")");
			
			lstMapUser.removeAll();
			java.util.List mus = gc.getMapUser();
			if(mus != null)
			for (Iterator iter = mus.iterator(); iter.hasNext();) {
				MapUser mu = (MapUser) iter.next();
				lstMapUser.add(mu.getName()+"("+mu.getId()+")"+" "+(mu.isMale()?"男":"女"));
			};
		}
	}
	
	private void refreshFightTab()
	{
		GameContext gc = mGameClient.getGameContext();
		lblSecPer.setText(String.valueOf(gc.getFightSecPer()));
		lblKillPer.setText(String.valueOf(gc.getFightKillPer()));;
		lblCityPer.setText(String.valueOf(gc.getFightCityPer()));;
		
		lblOnlineTime.setText(getTimeStr(System.currentTimeMillis() - gc.getLoginTime()));
		lblKillTime.setText(getTimeStr(gc.getFightKillTime()));
		lblCityTime.setText(getTimeStr(gc.getFightCityTime()));
	}
	
	private String getTimeStr(long t)
	{
		t = t / 1000; // seconds
		
		int d = (int) t / (24*3600);
		int h = (int) (t / 3600) % 24;
		int m = (int) (t / 60) % 60;
		int s = (int) t % 60;
		
		return d+" "+h+":"+m+":"+s;
	}
	
	private void refreshRoleTab()
	{
		// main info
		DotUser du = mGameClient.getDotUser();
		
		if(du != null)
		{
			lblBagVal.setText(du.getBagNow()+"/"+du.getBagMax());
			lblDemonVal.setText(String.valueOf(du.getDemoned()));
			lblExpVal.setText(du.getExpNow()+"/"+du.getExpMax());
			lblHpVal.setText(du.getHpNow()+"/"+du.getHpMax());
			lblKilledVal.setText(String.valueOf(du.getKilled()));
			lblLevelVal.setText(du.getApFree()+"/"+du.getApMax());
			lblMoneyVal.setText(String.valueOf(du.getMoney()));
			lblMpVal.setText(du.getMpNow()+"/"+du.getMpMax());
			grpRoleInfo.setText((du.isMale()?"男":"女")+" "+du.getGameName()+"("+du.getGameId()+")  "+du.getCountry());
		}
		
		
		// chat group
		java.util.List cis = mGameClient.getGameContext().getChatRcv();
		if(cis != null && cis.size() > 0)
		{
			int lc = txtRoleChatRcv.getLineCount()-1;
			int ll = 0;
			for (Iterator iter = cis.iterator(); iter.hasNext();) 
			{
				ChatItem ci = (ChatItem) iter.next();
				
				Color color = null;
				String type = null;
				String text = null;
				switch(ci.getType())
				{
					case ChatItem.TYPE_SYSTEM:
						type = "系";
						color = colorTomato;
						text = ci.getPlainText();
					break;
					case ChatItem.TYPE_COUNTRY:
						type = "国";
						color = colorPink;
						text = "["+(ci.isMale()?"男":"女")+"] "+ci.getUsername()+"("+ci.getUserid()+") "+ci.getPlainText();
					break;
					case ChatItem.TYPE_PRIVATE:
						type = "私";
						color = colorLightGreen;
						text = "["+(ci.isMale()?"男":"女")+"] "+ci.getUsername()+"("+ci.getUserid()+") "+ci.getPlainText();
					break;
					case ChatItem.TYPE_GROUP:
						type = "组";
						color = colorSlateBlue;
						text = "["+(ci.isMale()?"男":"女")+"] "+ci.getUsername()+"("+ci.getUserid()+") "+ci.getPlainText();
					break;
					case ChatItem.TYPE_WORLD:
						type = "世";
						text = "["+(ci.isMale()?"男":"女")+"] "+ci.getUsername()+"("+ci.getUserid()+") "+ci.getPlainText();
					break;
					case ChatItem.TYPE_NOTICE:
						type = "信";
						text = ci.getPlainText();
						color = colorGold;
					break;
					default:
						type = "错";
				}

				String line = ci.getTime()+" ["+type+"]"+text+txtRoleChatRcv.getLineDelimiter();
				
				txtRoleChatRcv.append(line);
				
				if(color != null)
				txtRoleChatRcv.setLineBackground(lc+ll, 1, color);
				
				ci.setRead(true);
				ll++;
			}

			txtRoleChatRcv.setSelection(txtRoleChatRcv.getCharCount());
			txtRoleChatSnd.forceFocus();
		}
	}
	private void refreshData()
	{
		if(!mGameClient.isLogined()) return;
		
		refreshCount ++;
		
		// user list  500*10 = 5 S
		if(refreshCount % 2 == 0) refreshUserList();
		
		// sys info
		if(refreshCount % 2 == 0) refreshSysInfo();
		
		// roleTab
		if(refreshCount % 2 == 0) refreshRoleTab();
		
		// mapTab
		if(refreshCount % 5 == 0) refreshMapTab();
		
		// fightTab
		if(refreshCount % 2 == 0) refreshFightTab();
		
		// config
		if(refreshCount % 5 == 0) refreshConf();
	}
	
	///////////
	private void sendChatData()
	{
		String str = txtRoleChatSnd.getText();
		if(str == null || str.trim().length() == 0) return;
		
		mGameClient.chat(str.trim());
		txtRoleChatSnd.setText("");
		txtRoleChatSnd.forceFocus();
	}
	
	/////
	private void tfDetailWidgetSelected(SelectionEvent evt) 
	{
		System.out.println("tfDetail.widgetSelected, event=" + evt);
	}
	
	private void btnRoleChatSndSelected(SelectionEvent evt) 
	{
		sendChatData();
	}
	
	private void btnDengluWidgetSelected(SelectionEvent evt) 
	{
		DlgLogin dlgLogin = new DlgLogin(dialogShell,SWT.NULL);
		dlgLogin.open();
		
		/*
		if(yh.getZhuangtai() == DotUser.STATUS_LOGIN)
		{
			if(mMainLoop.getYonghu(yh.getMingcheng()) != null)
			{
				MessageBox mb = new MessageBox(getParent(),SWT.OK |SWT.ICON_WARNING);
				mb.setMessage(yh.getMingcheng()+" exists!");
				mb.open();
				return;
			}
			lstYonghu.add("["+yh.getZhuangtaiMing()+"] "+yh.getMingcheng(),0);
			lstYonghu.select(0);
			mMainLoop.addYonghu(yh);
			mYonghu = yh;
		}
		else
		{
			System.out.println("failed to login:" + yh);
		}
		*/
	}
	
	private void btnChongdengWidgetSelected(SelectionEvent evt)
	{
	}
	
	private void btnDengchuWidgetSelected(SelectionEvent evt) 
	{
	}
	
	private void lstDotUsersSelected(SelectionEvent evt) 
	{
		if(lstDotUsers.getSelection().length ==1)
		{
			String text = lstDotUsers.getSelection()[0];
			String loginId = text.substring(text.indexOf(']')+1).trim();
			if(!loginId.equals(mGameClient.getDotUser().getLoginId()))
			{
				GameClient gc = (GameClient)mGameClientMap.get(loginId);
				
				mGameClient = gc;
				mDotMap = gc.getDotMap();
				isConfModified = true;
				
				//TODO
			}
		}
	}
	
	private void txtRoleChatSndKeyReleased(KeyEvent evt) 
	{
		if(evt.keyCode == 13)
		{
			sendChatData();
		}
	}
	
	private void onClickMapCell(MouseEvent evt) 
	{
		if(mDotMap == null) return;
		
		Label cell = (Label)evt.widget;
		String key = cell.getText();
		int p1 = key.indexOf('-');
		int p2 = key.indexOf(',');
		int x = Integer.parseInt(key.substring(p1+1, p2));
		int y = Integer.parseInt(key.substring(p2+1));
		
		GameContext gc = mGameClient.getGameContext();
		
		gc.setUserX(x+mDotMap.getMapX());
		gc.setUserY(y+mDotMap.getMapY());
		
		rdoMapHold.setSelection(true);
		rdoMapRandom.setSelection(false);
		mGameClient.getUserConf().setMapRandom(false);
		isConfModified = true;
		
		refreshMapTab();
	}
	
	private void onHoverMapCell(MouseEvent evt,boolean enter)
	{
		if(enter)
		{
			if(mDotMap == null) return;
			
			Label cell = (Label)evt.widget;
			String key = cell.getText();
			int p1 = key.indexOf('-');
			int p2 = key.indexOf(',');
			int x = Integer.parseInt(key.substring(p1+1, p2));
			int y = Integer.parseInt(key.substring(p2+1));

			MapCity mc = mDotMap.getCity(x, y);
			if(mc != null)
			{
				StringBuffer sb = new StringBuffer();
				sb.append("\n国家:"+mc.getName()+"("+(x+mDotMap.getMapX())+","+(y+mDotMap.getMapY()+")"));
				sb.append("\n国王:"+mc.getKingName());
				sb.append("\n　　:"+mc.getKingId());
				sb.append("\n领土:"+mc.getTownCnt()+" 金钱:"+mc.getMoney());
				sb.append("\n士兵:"+mc.getSoldierCnt()+" 国民:"+mc.getCitizenCnt());
				lblMapCellTip.setText(sb.toString());
				lblMapCellTip.setVisible(true);
				grpMapCtrl.setVisible(false);
			}
		}
		else
		{
			grpMapCtrl.setVisible(true);
			lblMapCellTip.setVisible(false);
		}
	}
	
	
	private void onMapMove(int dir)
	{
		mGameClient.move(dir);
	}
	
	private void onSetMapType() 
	{
		int cnt = 0;
		if(chkMapGrass.getSelection()) cnt ++;
		if(chkMapLand.getSelection())  cnt ++;
		if(chkMapMarsh.getSelection()) cnt ++;
		if(chkMapSand.getSelection())  cnt ++;
		if(chkMapSnow.getSelection())  cnt ++;
		if(chkMapWater.getSelection()) cnt ++;
		if(chkMapWoods.getSelection()) cnt ++;
		
		int index = 0;
		int[] types = new int[cnt];
		if(chkMapGrass.getSelection()) types[index++] = DotMap.TYPE_GRASS;
		if(chkMapLand.getSelection())  types[index++] = DotMap.TYPE_LAND;
		if(chkMapMarsh.getSelection()) types[index++] = DotMap.TYPE_MARSH;
		if(chkMapSand.getSelection())  types[index++] = DotMap.TYPE_SAND;
		if(chkMapSnow.getSelection())  types[index++] = DotMap.TYPE_SNOW;
		if(chkMapWater.getSelection()) types[index++] = DotMap.TYPE_WATER;
		if(chkMapWoods.getSelection()) types[index++] = DotMap.TYPE_WOODS;
		
		mGameClient.getUserConf().setMapType(types);
		isConfModified = true;
	}
	
	private void onChangeMagic(int type)
	{
		Map magics = mGameClient.getGameContext().getMagicMap();
		UserConf uc = mGameClient.getUserConf();
		int index1 = lstMagicHave.getSelectionIndex();
		if(type ==1 && index1 < 0) return;
		int index2 = lstMagicSeq.getSelectionIndex();
		if(index2 < 0)
		{
			index2 = lstMagicSeq.getItemCount()-1;
			lstMagicSeq.setSelection(index2);
		}
		String[] ms1 = uc.getAttack();
		
//		lstMagicHave
//		lstMagicSeq
		switch(type)
		{
			case 1: // in
				String name = lstMagicHave.getItem(index1);
				for (Iterator iter = magics.values().iterator(); iter.hasNext();) 
				{
					Magic m = (Magic) iter.next();
					if(name.indexOf(m.getName())>=0)
					{
						String[] ms2 = new String[ms1.length+1];
						
						int i=0;
						for (int j = 0; j < ms2.length; j++) 
						{
							if(j == index2+1)
							{
								ms2[j] = m.getId();
							}
							{
								if(i<ms1.length)
								{
									ms2[j] = ms1[i];
									i++;
								}
							}
						}
						uc.setAttack(ms2);
						break;
					}
				}
				break;
			case 2: // out
				String[] ms2 = new String[ms1.length-1];
				int i=0;
				for (int j = 0; j < ms1.length; j++) 
				{
					if(j != index2)
					{
						ms2[i] = ms1[j];
						i++;
					}
				}
				//lstMagicSeq.remove(index2);
				uc.setAttack(ms2);
				break;
			case 3: // up
				if(index2>0)
				{
					String t = ms1[index2];
					ms1[index2] = ms1[index2-1];
					ms1[index2-1] = t;
				}
				break;
			case 4: // down
				if(index2 < ms1.length-1)
				{
					String t = ms1[index2];
					ms1[index2] = ms1[index2+1];
					ms1[index2+1] = t;
				}
				break;
		}
		isConfModified = true;
	}
	private void onChangeFight(Button b,Text t)
	{
		UserConf uc = mGameClient.getUserConf();
		
		int val = 0;
		try
		{
			val = Integer.parseInt(t.getText().trim());
		}
		catch(Exception e)
		{
			return;
		}
		
		if(b != null) //check box
		{
			t.setEditable(!b.getSelection());
			if(b.getSelection()) val = -val;
		}

		if(t == txtFightRepair)
			uc.setRepair(val);
		else if(t == txtFightRestBag)
			uc.setSellBag(val);
		else if(t == txtFightRestHp)
			uc.setSleepHp(val);
		else if(t == txtFightRestMp)
			uc.setSleepMp(val);
		else if(t == txtFightRestPurify)
			uc.setPurify(val);
		
		isConfModified = true;
	}
}
