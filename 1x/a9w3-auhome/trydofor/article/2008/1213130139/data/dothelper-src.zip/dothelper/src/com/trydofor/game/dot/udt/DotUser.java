package com.trydofor.game.dot.udt;



public class DotUser 
{
	////
	// 人物属性
	private String  loginId;  // 登录名
	private String  gameId;   // 游戏id
	private String  gameName; // 游戏名
	private boolean male;	  // 男
	private String  country;  // 国家
	private String  vocation; // 职业
	private String  tribe;    // 种族
	
	// 基本信息

	private int killed;
	private int money;
	private int demoned;	//魔化
	private int apstore;	//ap储备
	
	private int hpMax;
	private int hpNow;
	private int mpMax;
	private int mpNow;
	private int epNow;
	private int epMax;
	private int apMax;
	private int apFree;
	private int expMax;
	private int expNow;
	private int bagMax;
	private int bagNow;
	
	private int strMax;	//力量
	private int strNow;	//力量
	private int rstMax; //耐力
	private int rstNow; //耐力
	private int dexMax; //敏捷
	private int dexNow; //敏捷
	private int actMax; //反应
	private int actNow; //反应
	private int intlMax; //智慧
	private int intlNow;//智慧
	private int chmMax;//魅力
	private int chmNow;//魅力
	private int wlpMax;//毅力
	private int wlpNow;//毅力
	private int svyMax;//悟性
	private int svyNow;//悟性
	
	public DotUser()
	{
	}
	/// getters & setters
	
	public int getActMax() {
		return actMax;
	}

	public void setActMax(int actMax) {
		this.actMax = actMax;
	}

	public int getActNow() {
		return actNow;
	}

	public void setActNow(int actNow) {
		this.actNow = actNow;
	}

	public int getApFree() {
		return apFree;
	}

	public void setApFree(int apFree) {
		this.apFree = apFree;
	}

	public int getApMax() {
		return apMax;
	}

	public void setApMax(int apMax) {
		this.apMax = apMax;
	}

	public int getApstore() {
		return apstore;
	}

	public void setApstore(int apstore) {
		this.apstore = apstore;
	}

	public int getBagMax() {
		return bagMax;
	}

	public void setBagMax(int bagMax) {
		this.bagMax = bagMax;
	}

	public int getBagNow() {
		return bagNow;
	}

	public void setBagNow(int bagNow) {
		this.bagNow = bagNow;
	}

	public int getChmMax() {
		return chmMax;
	}

	public void setChmMax(int chmMax) {
		this.chmMax = chmMax;
	}

	public int getChmNow() {
		return chmNow;
	}

	public void setChmNow(int chmNow) {
		this.chmNow = chmNow;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public int getDemoned() {
		return demoned;
	}

	public void setDemoned(int demoned) {
		this.demoned = demoned;
	}

	public int getDexMax() {
		return dexMax;
	}

	public void setDexMax(int dexMax) {
		this.dexMax = dexMax;
	}

	public int getDexNow() {
		return dexNow;
	}

	public void setDexNow(int dexNow) {
		this.dexNow = dexNow;
	}

	public int getExpMax() {
		return expMax;
	}

	public void setExpMax(int expMax) {
		this.expMax = expMax;
	}

	public int getExpNow() {
		return expNow;
	}

	public void setExpNow(int expNow) {
		this.expNow = expNow;
	}

	public String getGameId() {
		return gameId;
	}

	public void setGameId(String gameId) {
		this.gameId = gameId;
	}

	public String getGameName() {
		return gameName;
	}

	public void setGameName(String gameName) {
		this.gameName = gameName;
	}

	public int getHpMax() {
		return hpMax;
	}

	public void setHpMax(int hpMax) {
		this.hpMax = hpMax;
	}

	public int getHpNow() {
		return hpNow;
	}

	public void setHpNow(int hpNow) {
		this.hpNow = hpNow;
	}

	public int getIntlMax() {
		return intlMax;
	}

	public void setIntlMax(int intlMax) {
		this.intlMax = intlMax;
	}

	public int getIntlNow() {
		return intlNow;
	}

	public void setIntlNow(int intlNow) {
		this.intlNow = intlNow;
	}

	public int getKilled() {
		return killed;
	}

	public void setKilled(int killed) {
		this.killed = killed;
	}

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public boolean isMale() {
		return male;
	}

	public void setMale(boolean male) {
		this.male = male;
	}

	public int getMoney() {
		return money;
	}

	public void setMoney(int money) {
		this.money = money;
	}

	public int getMpMax() {
		return mpMax;
	}

	public void setMpMax(int mpMax) {
		this.mpMax = mpMax;
	}

	public int getMpNow() {
		return mpNow;
	}

	public void setMpNow(int mpNow) {
		this.mpNow = mpNow;
	}

	public int getRstMax() {
		return rstMax;
	}

	public void setRstMax(int rstMax) {
		this.rstMax = rstMax;
	}

	public int getRstNow() {
		return rstNow;
	}

	public void setRstNow(int rstNow) {
		this.rstNow = rstNow;
	}

	public int getStrMax() {
		return strMax;
	}

	public void setStrMax(int strMax) {
		this.strMax = strMax;
	}

	public int getStrNow() {
		return strNow;
	}

	public void setStrNow(int strNow) {
		this.strNow = strNow;
	}

	public int getSvyMax() {
		return svyMax;
	}

	public void setSvyMax(int svyMax) {
		this.svyMax = svyMax;
	}

	public int getSvyNow() {
		return svyNow;
	}

	public void setSvyNow(int svyNow) {
		this.svyNow = svyNow;
	}

	public String getTribe() {
		return tribe;
	}

	public void setTribe(String tribe) {
		this.tribe = tribe;
	}

	public String getVocation() {
		return vocation;
	}

	public void setVocation(String vocation) {
		this.vocation = vocation;
	}

	public int getWlpMax() {
		return wlpMax;
	}

	public void setWlpMax(int wlpMax) {
		this.wlpMax = wlpMax;
	}

	public int getWlpNow() {
		return wlpNow;
	}

	public void setWlpNow(int wlpNow) {
		this.wlpNow = wlpNow;
	}

	public int getEpMax() {
		return epMax;
	}

	public void setEpMax(int epMax) {
		this.epMax = epMax;
	}

	public int getEpNow() {
		return epNow;
	}

	public void setEpNow(int epNow) {
		this.epNow = epNow;
	}

	public void addKilled()
	{
		killed++;
		demoned++;
	}
}
