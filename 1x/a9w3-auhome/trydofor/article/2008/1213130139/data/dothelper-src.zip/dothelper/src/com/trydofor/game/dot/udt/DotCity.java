package com.trydofor.game.dot.udt;

public class DotCity {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
