package com.trydofor.game.dot.udt;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ChatItem {

	public static final int TYPE_UNKNOWN = 0;
	public static final int TYPE_PRIVATE = 1;
	public static final int TYPE_GROUP   = 2;
	public static final int TYPE_COUNTRY = 3;
	public static final int TYPE_WORLD   = 4;
	public static final int TYPE_SYSTEM  = 5;
	public static final int TYPE_NOTICE  = 6;
	
	public static final Pattern htmPattern = Pattern.compile("&#(\\d+);");
	
	
	private boolean read;
	
	private int type = TYPE_UNKNOWN;
	private String  time;
	private String  text;
	private boolean male;
	private String userid;
	private String username;
	
	public boolean isMale() {
		return male;
	}
	public void setMale(boolean male) {
		this.male = male;
	}
	public boolean isRead() {
		return read;
	}
	public void setRead(boolean read) {
		this.read = read;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) 
	{
		if(text != null)
		{
			this.text = text.trim();
		}
		else
		{
			this.text = null;
		}
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getPlainText() 
	{
		return transHtml(text);
	}
	
	private String transHtml(String str)
	{
		if(str == null) return null;
		
		try
		{
			Matcher m = htmPattern.matcher(str);
			int pos = 0;
			while(m.find(pos))
			{
				int code = Integer.parseInt(m.group(1));
				str = str.replaceAll(m.group(), String.valueOf((char)code));
				pos = m.end();
			}
		}
		catch(Exception e)
		{
		}
		return str;
	}
	private String transEmotion(String str)
	{
		return null;
	}
	
}
