package com.trydofor.game.dot.gui;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import com.trydofor.game.dot.udt.DotUser;

public class DlgLogin extends org.eclipse.swt.widgets.Dialog {

	private DotUser mDotUser;
	
	private Shell dialogShell;
	private Composite cmpRoot;
	private Label lblYonghu;
	private Label lblMima;
	private Text txtYonghu;
	private Text txtMima;
	private Button btnQuxiao;
	private Button btnDenglu;

	public DlgLogin(Shell parent, int style) {
		super(parent, style);
	}

	public void setDotUser(DotUser dotUser)
	{
		mDotUser = dotUser;
	}
	
	public void open() {
		try {
			Shell parent = getParent();
			dialogShell = new Shell(parent,SWT.DIALOG_TRIM | SWT.APPLICATION_MODAL);
			dialogShell.setText("\u767b\u5f55");
			dialogShell.setLayout(null);
			{
				cmpRoot = new Composite(dialogShell, SWT.NONE);
				cmpRoot.setLayout(null);
				cmpRoot.setBounds(0, 0, 160, 100);
				{
					lblYonghu = new Label(cmpRoot, SWT.NONE);
					lblYonghu.setText("\u7528\u6237:");
					lblYonghu.setBounds(10, 20, 40, 12);
				}
				{
					txtYonghu = new Text(cmpRoot, SWT.BORDER |SWT.NONE);
					txtYonghu.setBounds(50, 18, 100, 18);
				}
				{
					lblMima = new Label(cmpRoot, SWT.NONE);
					lblMima.setText("\u5bc6\u7801:");
					lblMima.setBounds(10, 42, 40, 12);
				}
				{
					txtMima = new Text(cmpRoot, SWT.BORDER | SWT.PASSWORD);
					txtMima.setBounds(50, 40, 100, 18);
				}
				{
					btnDenglu = new Button(cmpRoot, SWT.PUSH | SWT.CENTER);
					btnDenglu.setText("\u767b\u5f55");
					btnDenglu.setBounds(15, 70, 60, 20);
					btnDenglu.addSelectionListener(new SelectionAdapter() {
						public void widgetSelected(SelectionEvent evt) {
							btnDengluWidgetSelected(evt);
						}
					});
				}
				{
					btnQuxiao = new Button(cmpRoot, SWT.PUSH | SWT.CENTER);
					btnQuxiao.setText("\u53d6\u6d88");
					btnQuxiao.setBounds(85, 70, 60, 20);
					btnQuxiao.addSelectionListener(new SelectionAdapter() {
						public void widgetSelected(SelectionEvent evt) {
							btnQuxiaoWidgetSelected(evt);
						}
					});
				}
			}
			dialogShell.layout();
			dialogShell.pack();
			dialogShell.setSize(170, 130);
			Point p = parent.getLocation();
			int w = (parent.getBounds().width - dialogShell.getBounds().width)/2;
			int h = (parent.getBounds().height - dialogShell.getBounds().height)/2;
			dialogShell.setLocation(p.x+w,p.y+h);
			dialogShell.open();
			Display display = dialogShell.getDisplay();
			while (!dialogShell.isDisposed()) {
				if (!display.readAndDispatch())
					display.sleep();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	///////////////////////////
	private void btnQuxiaoWidgetSelected(SelectionEvent evt) 
	{
		dialogShell.close();
		dialogShell.dispose();
	}
	
	private void btnDengluWidgetSelected(SelectionEvent evt)
	{
		String user = txtYonghu.getText().trim();
		String passwd = txtMima.getText().trim();
		
		if(user.length() == 0 || passwd.length() == 0)
		{
			MessageBox mb = new MessageBox(dialogShell,SWT.OK|SWT.ICON_ERROR);
			mb.setText("ERROR");
			mb.setMessage("username or passwd empty");
			dialogShell.close();
			dialogShell.dispose();
			
			return;
		}
		
		System.out.println("user:"+user+" passwd:"+passwd);
		
		dialogShell.close();
		dialogShell.dispose();
	}

}
