package com.trydofor.game.dot.udt;

public class MapCity 
{
	private String name;
	private String kingId;
	private String kingName;
	private int mapX; // 相对于地图
	private int mapY; // 相对于地图
	private int worldX;
	private int worldY;
	private int townCnt;
	private int citizenCnt;
	private int soldierCnt;
	private int money;
	
	public int getCitizenCnt() {
		return citizenCnt;
	}
	public void setCitizenCnt(int citizenCnt) {
		this.citizenCnt = citizenCnt;
	}
	public String getKingId() {
		return kingId;
	}
	public void setKingId(String kingId) {
		this.kingId = kingId;
	}
	public String getKingName() {
		return kingName;
	}
	public void setKingName(String kingName) {
		this.kingName = kingName;
	}
	public int getMapX() {
		return mapX;
	}
	public void setMapX(int mapX) {
		this.mapX = mapX;
	}
	public int getMapY() {
		return mapY;
	}
	public void setMapY(int mapY) {
		this.mapY = mapY;
	}
	public int getMoney() {
		return money;
	}
	public void setMoney(int money) {
		this.money = money;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSoldierCnt() {
		return soldierCnt;
	}
	public void setSoldierCnt(int soldierCnt) {
		this.soldierCnt = soldierCnt;
	}
	public int getTownCnt() {
		return townCnt;
	}
	public void setTownCnt(int townCnt) {
		this.townCnt = townCnt;
	}
	public int getWorldX() {
		return worldX;
	}
	public void setWorldX(int worldX) {
		this.worldX = worldX;
	}
	public int getWorldY() {
		return worldY;
	}
	public void setWorldY(int worldY) {
		this.worldY = worldY;
	}
	
	
}
