package com.trydofor.game.dot.test;

public class Test {

	public static void count(String str)
	{
		if(str == null) throw new IllegalArgumentException("str is null");
		
		int lc = 0;
		int uc = 0;
		for (int i = 0; i < str.length(); i++) 
		{
			char c = str.charAt(i);
			if(c>='a' && c <='z') lc++;
			else if(c>='A' && c <='Z') uc++;
		}
		
		System.out.println("lc:"+lc);
		System.out.println("uc:"+uc);
	}
	
	private static String getTimeStr(long t)
	{
		t = t / 1000; // seconds
		
		int d = (int) t / 24*3600;
		int h = (int) (t / 3600) % 24;
		int m = (int) (t / 60) % 60;
		int s = (int) t % 60;
		
		return d+" "+h+":"+m+":"+s;
	}
	
	public static void main(String[] args) 
	{
		System.out.println(getTimeStr(System.currentTimeMillis()));
	}
}
