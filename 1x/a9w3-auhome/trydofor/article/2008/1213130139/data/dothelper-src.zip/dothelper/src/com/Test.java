package com;

public class Test 
{

	public static void str(String o)
	{
		o = "other_str";
	}
	
	public static void arr1(String[] o)
	{
		o = new String[]{"other_item"};
	}
	
	public static void arr2(String[] o)
	{
		o[0]="other2_item";
	}
	
	public static void main(String[] args)
	{
		String array[] = new String[]{"init_item"};
		String str = "init_str";
		
		str(str);
		System.out.println(str);
		
		arr1(array);
		System.out.println(((String[])array)[0]);
		
		arr2(array);
		System.out.println(((String[])array)[0]);
	}
}
