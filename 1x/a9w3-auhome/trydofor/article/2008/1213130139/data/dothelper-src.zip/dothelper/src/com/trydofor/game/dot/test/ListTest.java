package com.trydofor.game.dot.test;

import java.util.LinkedList;
import java.util.List;

public class ListTest 
{

	public static void  main(String[] args)
	{
		List r = new LinkedList();
		r.add("1");
		r.add("2");
		List s = r.subList(0, r.size());
		System.out.println(s.size());
	}
}
