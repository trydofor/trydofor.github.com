package com.trydofor.game.dot.udt;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;


public class DotMap 
{
	//	terrain_name[1]="水";
	//	terrain_name[2]="土";
	//	terrain_name[3]="草";
	//	terrain_name[4]="沙";
	//	terrain_name[5]="雪";
	//	terrain_name[6]="沼";
	//	terrain_name[7]="林";


	public static final int TYPE_WATER = 1;
	public static final int TYPE_LAND  = 2;
	public static final int TYPE_GRASS = 3;
	public static final int TYPE_SAND  = 4;
	public static final int TYPE_SNOW  = 5;
	public static final int TYPE_MARSH = 6;
	public static final int TYPE_WOODS = 7;
	public static final int TYPE_TOWN  = 8;
	public static final int TYPE_CITY  = 9;
	
	public static final int MAX_MAP_WIDTH  = 960;
	public static final int MAX_MAP_HEIGHT = 960;
	public static final int MAP_TYPE_MATRIX = 25;
	
	public static final int MOVE_LEFT  = 0; //mex=23,     mey= <0-23>,dir=0  west
	public static final int MOVE_RIGHT = 1; //mex= 0,     mey= <0-23>,dir=1  east
	public static final int MOVE_UP    = 2; //mex= <0-23>,mey=23,     dir=2  north
	public static final int MOVE_DOWN  = 3; //mex= <0-23>,mey= 0,     dir=3  south
	
	// 地图24*24,编号从0开始,第25列,是下一地图的
	private int[]   mapTypes = new int[ MAP_TYPE_MATRIX * MAP_TYPE_MATRIX ];
	private int[][] typeDict = new int[10][];
	private Random  random = new Random();
	
	private Map mapCitys = new HashMap();
	
	///////////
	private int theMapX = 0;
	private int theMapY = 0;

	public DotMap(int x , int y)
	{
		theMapX = x;
		theMapY = y;
	}
	
	public int getMapX() {
		return theMapX;
	}

	public int getMapY() {
		return theMapY;
	}
	
	public int getRandomMap(int[] types)
	{
		int p = getIndex(9,9);
		
		try
		{
			int[] ts = null;
			int cnt = 0;
			while(cnt < 10 && (ts == null || ts.length <= 0))
			{
				int i = random.nextInt(types.length);
				ts = typeDict[types[i]];
				cnt ++;
			}
			
			p = ts[random.nextInt(ts.length)];
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return p;
	}
	
	// 2,2,5,5,5,5,2,2,2,2,5,5,5,5,5,5,7
	public void initMapTypes(String str)
	{
		if(str == null || str.length() < mapTypes.length)
			throw new IllegalArgumentException("wrong format:"+str);
		
		int j = -1;
		for(int i=0; i<str.length();i++)
		{
			char c = str.charAt(i);
			if(c < '8' && c > '0')
			{
				j++;
				mapTypes[j] = (c - '0');
			}
			if(j == mapTypes.length -1) break;
		}
		
		if(j != mapTypes.length-1) throw new IllegalStateException("length wrong j:"+j+","+str);
		
		//
		typeDict[0] = mapTypes;
		
		StringBuffer[] sbs = new StringBuffer[typeDict.length];
		int matrix = 24;
		for (int y = 0; y < matrix; y++)
		{
			for (int x = 0; x < matrix; x++)
			{
				int index = getIndex(x,y);
				int type  = mapTypes[index];
				if(sbs[type] == null) sbs[type] = new StringBuffer();
				sbs[type].append(',').append(index);
			}
		}
		
		for (int i = 1; i < sbs.length; i++) 
		{
			if(sbs[i] == null) continue;
			
			String[] strs = sbs[i].deleteCharAt(0).toString().split(",");
			typeDict[i] = new int[strs.length];
			for (int k = 0; k < strs.length; k++)
			{
				typeDict[i][k] = Integer.parseInt(strs[k]);
			}
		}
	}
	
	public void addTown(int x,int y)
	{
		int index = getIndex(x,y);
		if(index<0 || index > mapTypes.length-1) return;
		
		int type  = mapTypes[index];
		if (type != TYPE_CITY && type != TYPE_TOWN )
		{
			removeMapDict(type,index);
			mapTypes[index] = TYPE_TOWN;
		}
	}
	
	public void addCity(MapCity mc)
	{
		int index = getIndex(mc.getMapX(),mc.getMapY());
		
		// 游戏会添加下一地图的城,比如幻地
		if(index<0 || index>mapTypes.length-1) return;
		
		int type  = mapTypes[index];
		removeMapDict(type,index);
		
		mapTypes[index] = TYPE_CITY;
		mapCitys.put(new Integer(index), mc);
	}
	
	public MapCity getCity(int x,int y)
	{
		return (MapCity) mapCitys.get(new Integer(getIndex(x,y)));
	}
	
	public int getMapType(int x, int y)
	{
		return mapTypes[getIndex(x,y)];
	}
	

	public boolean isNowMap(int x,int y)
	{
		return theMapX == x && theMapY == y;
	}

	public boolean hasType(int type)
	{
		return typeDict[type] != null;
	}


	private void removeMapDict(int type,int index)
	{
		int[] tt = typeDict[type];
		
		if(tt == null) return;
		
		if(tt.length == 1)
		{
			if(tt[0] != index)
			{
				typeDict[type] = null;
			}
		}
		else
		{
			boolean in = false;
			for (int i = 0; i < tt.length; i++) 
			{
				if(index == tt[i])
				{
					in = true;
					break;
				}
			}
			
			if(!in) return;
			
			int[] nt = new int[tt.length-1];
			
			int j = 0;
			for (int i = 0; i < tt.length; i++) 
			{
				if(index == tt[i]) continue;
				
				nt[j] = tt[i];
				j++;
			}
			
			typeDict[type] = nt;
		}
	}

	private int getIndex(int x, int y)
	{
		return MAP_TYPE_MATRIX*y + x;
	}
	
	public static void main(String[] args)
	{
		DotMap dm = new DotMap(0,0);
		dm.initMapTypes("2,2,5,5,5,5,2,2,2,2,5,5,5,5,5,5,7,7,7,7,5,5,5,5,5,2,2,5,5,5,5,2,2,2,2,5,5,5,5,5,5,7,7,7,7,5,5,5,5,5,5,5,5,5,5,5,2,2,5,5,5,5,5,5,5,5,7,7,7,7,5,5,5,5,5,5,5,5,5,5,5,2,2,5,5,5,5,5,5,5,5,7,7,7,7,5,5,5,5,5,5,5,5,5,5,5,2,2,7,7,7,7,7,7,7,7,5,5,7,7,5,5,5,5,5,5,5,5,5,5,5,2,2,7,7,7,7,7,7,7,7,5,5,7,7,5,5,5,5,5,5,5,5,5,7,7,7,7,7,7,7,7,7,7,5,5,7,7,5,5,5,5,5,5,5,5,5,5,5,7,7,7,7,7,7,7,7,7,7,5,5,7,7,5,5,5,5,5,5,5,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,5,5,5,5,5,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,5,5,5,5,5,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,5,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,5,7,7,7,7,7,7,7,7,7,7,7,7,7,7,5,5,7,7,7,7,5,5,5,5,5,7,7,7,7,7,7,7,7,7,7,7,7,7,7,5,5,7,7,7,7,5,5,5,5,5,7,7,7,7,7,7,7,7,7,7,7,7,7,7,5,5,7,7,7,7,7,7,7,7,5,7,7,7,7,7,7,7,7,7,7,7,7,7,7,5,5,7,7,7,7,7,7,7,7,5,7,7,7,7,7,7,7,7,7,7,7,7,7,7,5,5,7,7,7,7,7,7,7,7,5,7,7,7,7,7,7,7,7,7,7,7,7,7,7,5,5,7,7,7,7,7,7,7,7,5,5,5,7,7,5,5,5,5,5,5,7,7,5,5,5,5,5,5,7,7,5,5,5,5,5,5,5,7,7,5,5,5,5,5,5,7,7,5,5,5,5,5,5,7,7,5,5,5,5,5,7,7,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,7,7,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,7,7,7,7,5,5,5,5,2,2,2,2,5,5,5,5,5,5,5,5,5,5,5,5,5,7,7,7,7,5,5,5,5,2,2,2,2,5,5,5,5,5,5,5,5,5,5,5,5,5,7,7,5,5,7,7,5,5,2,2,2,2,2,2,5,5,5,5,5,5,5,5,5,5,5);");
		
		int[] types = {2,5,7};
		for (int i = 0; i < 100; i++) 
		{
			int index = dm.getRandomMap(types);
			System.out.println(index +":"+dm.mapTypes[index]);
		}
	}
}
