package com.trydofor.game.dot.biz;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpMethodBase;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.MultiThreadedHttpConnectionManager;
import org.apache.commons.httpclient.cookie.CookiePolicy;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.trydofor.game.dot.udt.ChatItem;
import com.trydofor.game.dot.udt.DotMap;
import com.trydofor.game.dot.udt.DotUser;
import com.trydofor.game.dot.udt.GameContext;
import com.trydofor.game.dot.udt.Magic;
import com.trydofor.game.dot.udt.MapCity;
import com.trydofor.game.dot.udt.MapUser;
import com.trydofor.game.dot.udt.SysInfo;
import com.trydofor.game.dot.udt.UserConf;


public class GameClient extends Thread 
{
	private static final Logger logger   = Logger.getLogger(GameClient.class);

	private final SimpleDateFormat mSDFymdhms = new SimpleDateFormat("yyyyMMdd_HHmmss.SSS");
	private final SimpleDateFormat mSDFhms = new SimpleDateFormat("HH:mm:ss");
	
	private final HttpClient mHttpClient;
	private final ScriptReceiver mScriptReceiver = new ScriptReceiver();
	private final GameContext    mGameContext = new GameContext();
	private final DotUser  mDotUser = new DotUser();
	private final UserConf mUserConf;
	private final Random mRandom =  new Random();

	private String mHttpHost = null;
	
	private DotMap  mDotMap		= null;
	private SysInfo mSysInfo	= null;

	
	private volatile boolean needClose  = false;
	private volatile boolean needPause  = false;
	private volatile boolean needLogin  = true;
	
	public GameClient(UserConf uc)
	{
		if(uc == null) throw new IllegalStateException("no userConf to deal");
		this.mUserConf = uc;
		mDotUser.setLoginId(uc.getLoginId());
		
		MultiThreadedHttpConnectionManager connectionManager = new MultiThreadedHttpConnectionManager();
		mHttpClient = new HttpClient(connectionManager);
	}
	
	public void setSysInfo(SysInfo si)
	{
		mSysInfo = si;
	}
	public SysInfo getSysInfo()
	{
		return mSysInfo;
	}
	public DotUser getDotUser() {
		return mDotUser;
	}
	public UserConf getUserConf()
	{
		return mUserConf;
	}
	public GameContext getGameContext()
	{
		return mGameContext;
	}
	public DotMap 	getDotMap()
	{
		return mDotMap;
	}
	public void close()
	{
		mScriptReceiver.close();
		needClose = true;
	}
	
	public void setPause(boolean pause)
	{
		needPause = pause;
	}
	
	public void relogin()
	{
		needLogin = true;
	}
	
	public void chat(String msg)
	{
		// userid=fairyking&cardid=2&text=private+talk+1&color=1&channelid=&msgid=501010
		msg = gbk2Iso(msg);

		PostMethod pm = new PostMethod(mHttpHost+"/chat_http_client/sendMessage.jsp");
		pm.setParameter("msgid", "501000");
		pm.setParameter("color", "1");
		pm.setParameter("userid", "");
		pm.setParameter("cardid", "");

		char c = msg.charAt(0);
		if(c == '/' || c == '#') // private &　ｇｒｏｕｐ　ｃｈａｔ
		{
			int p = msg.indexOf(' ');
			String userid = msg.substring(1, p).trim();
			String cid = null;
			if(c == '#')
				cid = mGameContext.getChatGroupChannel(userid);
			else
				cid = mGameContext.getChatPrivateChannel(userid);
			
			if(cid == null)
			{
				pm.setParameter("userid", userid);
				pm.setParameter("msgid", "501010");
				pm.setParameter("cardid", "2");
				pm.setParameter("channelid", "");
			}
			else
			{
				pm.setParameter("channelid", cid);
			}

			pm.setParameter("text", msg.substring(p+1));
		}
		else if( c == '!') // country talk
		{
			pm.setParameter("channelid", mGameContext.getChatCountryChannel());
			pm.setParameter("text", msg.substring(1).trim());
		}
		else // world talk
		{
			pm.setParameter("channelid", mGameContext.getChatWorldChannel());
			pm.setParameter("text", msg.trim());
		}
		
		try {
			doRequest(pm);
		} catch (Exception e) {
			logger.error(mDotUser.getLoginId()+"@failed to send chat:"+msg);
		}
	}
	public void move(int w)
	{
		int x = mGameContext.getUserX() - mDotMap.getMapX();
		int y = mGameContext.getUserY() - mDotMap.getMapY();
		
		if(x<=0) x = 0;
		if(x>=23) x = 23;
		
		if(y<=0) y = 0;
		if(y>=23) y = 23;		
		
		if(w == DotMap.MOVE_UP) y = 23;
		else if( w == DotMap.MOVE_DOWN)  y = 0;
		else if( w == DotMap.MOVE_LEFT)  x = 23;
		else if( w == DotMap.MOVE_RIGHT) x = 0;
		else throw new IllegalArgumentException("move type error:"+w);
		
		String url = mHttpHost+"/main/_map.jsp?mex="+x+"&mey="+y+"&dir="+w+"&timestamp="+System.currentTimeMillis();
		
		GetMethod gm = new GetMethod(url);
		logger.info(mDotUser.getLoginId()+"@move "+url);
		try {
			String mapInfo = doRequest(gm);
			parseDotMap(mapInfo);
		} catch (Exception e) {
			logger.error(mDotUser.getLoginId()+"@faild to move", e);
		}
	}
	
	///
	public void run() 
	{
		logger.info("game client start:" + mDotUser.getLoginId());
		needLogin = true;
		long lastCity = System.currentTimeMillis();
		long lastFight = lastCity;
		long lastLogin = 0;
		int killed = 0;
		
		while(!needClose)
		{
			long fightIdle = mUserConf.getFightIdle()*1000;
			long cityIdle  = mUserConf.getCityIdle()*1000;
			long loginIdle = mUserConf.getLoginIdle()*1000;
			
			try
			{
				if(needPause)
				{
					mGameContext.setStatus(GameContext.STATUS_PAUSE);
					sleep(2000);
				}
				else
				{	
					if(needLogin || mGameContext.getStatus() == GameContext.STATUS_ERROR)
					{
						if(lastLogin != 0)
						{
							long sleep = (System.currentTimeMillis() - lastLogin) - loginIdle;
							if(sleep < 0) sleep(-sleep);
						}
						
						login();
						lastLogin = System.currentTimeMillis();
					}
					else
					{
						if(mDotUser.getKilled() % mUserConf.getRepair() == 0)
						{
							repair();
							if(needPause) continue;
						}
						
						if(
							(mUserConf.getSleepMp()>=0 && mDotUser.getMpNow()*100< mUserConf.getSleepMp()* mDotUser.getMpMax())
							|| (mUserConf.getSleepHp() >=0 && mDotUser.getHpNow()*100< mUserConf.getSleepHp()* mDotUser.getHpMax())
							|| (mUserConf.getSellBag() >=0 && mDotUser.getBagNow()*100 > mUserConf.getSellBag()* mDotUser.getBagMax())
							|| (mUserConf.getPurify() >=0 && mDotUser.getDemoned()>mUserConf.getPurify())
						  )
						{
							long sleep = (System.currentTimeMillis() - lastCity) - cityIdle;
							if(sleep < 0) sleep(-sleep);
							
							cityBiz();
							
							int cityper = killed;
							if(mGameContext.getFightCityPer() !=0)
							{
								cityper = (cityper + mGameContext.getFightCityPer())/2;
							}
							mGameContext.setFightCityPer(cityper);
							killed = 0;
							
							lastCity = System.currentTimeMillis();
							if(needPause) continue;
						}
						
						if(needPause) continue;
						
						long sleep = (System.currentTimeMillis() - lastFight) - fightIdle;
						if(sleep < 0) sleep(-sleep);

						fight();
						killed ++;
						lastFight = System.currentTimeMillis();
					}
				}
			}
			catch (Exception e) 
			{
				mGameContext.setStatus(GameContext.STATUS_ERROR);
				logger.error(mDotUser.getLoginId()+"@gameclient error:",e);
			}
		}
		logout();
		
		mGameContext.setStatus(GameContext.STATUS_STOP);
		logger.info("game manager stop:" + mDotUser.getLoginId());
	}
	
	///////
	public void login()
	{
		try 
		{
			mScriptReceiver.close();
			while(!mScriptReceiver.isStoped())
			{
				sleep(1000);
			}
			
			mGameContext.setStatus(GameContext.STATUS_LOGIN);
			
			if(mUserConf.isProxy())
			{
				mHttpClient.getHostConfiguration().setProxy(mUserConf.getProxyHost(),mUserConf.getProxyPort());
			}
			
			////////////////dot.mud2u.com/////////////////
			
			String url = mUserConf.getUrl();
			// get login page
			String[] postKeys = {"__VIEWSTATE","__EVENTVALIDATION","__EVENTTARGET","__EVENTARGUMENT"};
			String[] postVals = new String[postKeys.length];
			//
			{
				GetMethod gm = new GetMethod(url);
				String response = doRequest(gm);
				for (int i = 0; i < postKeys.length; i++) 
				{
					int pos1 = response.indexOf(postKeys[i]);
					int pos2 = response.indexOf("\n",pos1);
					String str1 = response.substring(pos1, pos2);
					int pos3 = str1.indexOf("value");
					int pos4 = str1.indexOf("\"",pos3)+1;
					int pos5 = str1.indexOf("\"",pos4);
					postVals[i] = str1.substring(pos4, pos5);
				}
			}
			
			// get servers
			String server = null;
			{
				PostMethod pm = new PostMethod(url);
				pm.setRequestHeader("Referer", url);
				for (int i = 0; i < postKeys.length; i++) 
				{
					pm.setParameter(postKeys[i], postVals[i]);
				}
				pm.setParameter("EnterGame1$txtUserName", mUserConf.getLoginId());
				pm.setParameter("EnterGame1$txtPasswd", mUserConf.getPasswd());
				pm.setParameter("EnterGame1$ImageButton1.x", "0");
				pm.setParameter("EnterGame1$ImageButton1.y", "0");
				
				String response = doRequest(pm);
				
				String token = "gotogame.aspx";
				int serverId = 0;
				int pos = -1;
				do
				{
					pos = response.indexOf(token,pos+1);
					if(pos > 0 )
					{
						serverId ++;
						String s = response.substring(pos, response.indexOf("'",pos+1));
						logger.info(mDotUser.getLoginId()+"@get server url:"+s);
						if(serverId == mUserConf.getServer())
						{
							server = s;
							break;
						}
					}
				}
				while(pos >0);
					
				if(server == null)
				{
					dump(pm);
					throw new HttpException("failed to get servers by token:"+token);
				}
			}
			
			// select world
			{	
				GetMethod gm = new GetMethod("http://dot.mud2u.com/dotgame/"+server);
				gm.setFollowRedirects(true);
				doRequest(gm);
				mHttpHost = "http://"+gm.getRequestHeader("Host").getValue();
				
				logger.info(mDotUser.getLoginId()+"@select world:"+server);
			}
	
			//////////////////////////////////////////////////////
			
			// enter world
			String uloginUrl = null;
			{
				GetMethod gm = new GetMethod(mHttpHost+"/member/enter_dot.jsp?targethost="+mUserConf.getWorld()+"&window=self");
				gm.setRequestHeader("Referer", mHttpHost+"/index.htm");
				String response = doRequest(gm);
				String token = "location.replace";
				int pos = response.indexOf(token);
				if (pos>0)
				{
					int pos2 = response.indexOf("\"",pos+1)+1;
					int pos3 = response.indexOf("\"",pos2);
					uloginUrl = response.substring(pos2,pos3);
					logger.info(mDotUser.getLoginId()+"@get user login url:"+uloginUrl);
				}
				
				if(uloginUrl == null)
				{
					dump(gm);
					throw new HttpException("failed to enter game");
				}
			}
			
			////////////////222.135.144.16/111 /////////////////
			// entergame
			{
				GetMethod gm = new GetMethod(uloginUrl);
				doRequest(gm);
				mHttpHost = "http://"+gm.getRequestHeader("Host").getValue();
				
				logger.info(mDotUser.getLoginId()+"@user login:"+uloginUrl);
			}
			
			{
				GetMethod gm = new GetMethod(mHttpHost+"/main/index.jsp?timestamp="+System.currentTimeMillis());
				doRequest(gm);
				logger.info(mDotUser.getLoginId()+"@get main/index.jsp");
			}

			// script receiver
			String chatUrl = null;
			{
				GetMethod gm = new GetMethod(mHttpHost+"/main/main.jsp");
				String response = doRequest(gm);
				
				response = iso2Gbk(response);
				initFight(response);
				parseDotUser(response);
				
				String token = "window.frames.chat_body.location.replace";
				
				int pos = response.indexOf(token);
				if(pos>0)
				{
					pos = pos + token.length();
					int pos1 = response.indexOf("\"",pos)+1;
					int pos2 = response.indexOf("\"",pos1);
					chatUrl = response.substring(pos1, pos2)+System.currentTimeMillis();
				}
				if(chatUrl == null)
				{
					dump(gm);
					throw new HttpException("failed to chat url");
				}
				else
				{
					String t = "channelid=";
					int p1 = chatUrl.indexOf(t);
					int p2 = chatUrl.indexOf("&",p1);
					if(p2>p1 && p1>0)
					{
						String[] channels = chatUrl.substring(p1+t.length(), p2).split("\\|");
						if(channels.length == 2)
						{
							mGameContext.setChatCountryChannel(channels[0]);
							mGameContext.setChatWorldChannel(channels[1]);
						}
						else if (channels.length == 1)
						{
							mGameContext.setChatWorldChannel(channels[0]);
						}
						else
						{
							logger.error(mDotUser.getLoginId()+"@failed to parse channel:"+chatUrl);
						}
					}
				}

				logger.info(mDotUser.getLoginId()+"@get chat url in main/main.jsp:"+chatUrl);
			}
			
			String chatsocketUrl = null;
			{
				GetMethod gm = new GetMethod(mHttpHost+"/"+chatUrl);
				String response = doRequest(gm);
				String token = "window.frames[\"chatsocket\"].location.replace";
				
				int pos = response.indexOf(token);
				if(pos>0)
				{
					pos = pos + token.length();
					int pos1 = response.indexOf("\"",pos+1)+1;
					int pos2 = response.indexOf("\"",pos1);
					chatsocketUrl = response.substring(pos1, pos2);
				}
				
				if(chatsocketUrl == null)
				{
					dump(gm);
					throw new HttpException("failed to chatsocket url");
				}

				logger.info(mDotUser.getLoginId()+"@get /chat_http_client/chat.jsp");
			}
			
			String bridgeUrl = null;
			{
				GetMethod gm = new GetMethod(mHttpHost+"/"+chatsocketUrl);
				String response = doRequest(gm);
				String token = "document.location.replace";
				
				int pos = response.indexOf(token);
				if(pos>0)
				{
					pos = pos + token.length();
					int pos1 = response.indexOf("'",pos+1)+1;
					int pos2 = response.indexOf("'",pos1);
					bridgeUrl = response.substring(pos1, pos2);
				}
				
				if(bridgeUrl == null)
				{
					dump(gm);
					throw new HttpException("failed to bridge url");
				}
				logger.info(mDotUser.getLoginId()+"@get /chat_http_client/http_client.jsp");
			}
			
			{
				mScriptReceiver.setChatURL(new URL(bridgeUrl));
				mScriptReceiver.start();
				logger.info(mDotUser.getLoginId()+"@init chat client");
			}
			
			// initmap
			{
				GetMethod gm = new GetMethod(mHttpHost+"/main/_map.jsp?type=init&time="+System.currentTimeMillis());
				String mapInfo = doRequest(gm);
				parseDotMap(mapInfo);
//				dump(gm);
				logger.info(mDotUser.getLoginId()+"@get main/_map.jsp");
			}
			
			// init magic
			{
				GetMethod gm = new GetMethod(mHttpHost+"/user/status_ability.jsp?timestamp="+System.currentTimeMillis());
				String magic = doRequest(gm);
				//dump(gm); //TODO debug
				magic = iso2Gbk(magic);
				initMagic(magic);
				logger.info(mDotUser.getLoginId()+"@get user/status_ability.jsp");
			}
		
			mGameContext.setLoginTime(System.currentTimeMillis());
			
			needLogin = false;
			
		} catch (Exception e) {
			logger.error(mDotUser.getLoginId()+"@failed to login", e);
			mGameContext.setStatus(GameContext.STATUS_ERROR);
		}
	}
	
	
	public void logout()
	{
		
		mGameContext.setStatus(GameContext.STATUS_LOGOUT);
	}
	
	///
	public void cityBiz()
	{
		mGameContext.setStatus(GameContext.STATUS_INCITY);
		long t = System.currentTimeMillis();
		try
		{
			String lgParam = null;// "/npc/construction.jsp?conid=lvguan",616,594);
			String sdParam = null; // "/npc/construction.jsp?conid=jinghuazhishendian",344,611);
			String wzParam = null;  // "/npc/construction.jsp?conid=wuzizhongxin",228,551);
			
			// enter City
			{
				GetMethod gm = new GetMethod(mHttpHost+"/nation/zoomin_nation.jsp?x="
						+mUserConf.getRestCityX()+"&y="+mUserConf.getRestCityY()+"&timestamp="+System.currentTimeMillis());
				String res = doRequest(gm);
				//dump(gm); //DEBUG
				
				// /npc/construction.jsp?conid=lvguan&x=616&y=594&timestamp=1185259637625
				String lgStr = getStrBetween(res, "\"/npc/construction.jsp?conid=lvguan\",", ")", 0);
				if(lgStr != null) lgParam = "x="+lgStr.replaceFirst(",", "&y=")+"&timestamp=";
				
				// /npc/construction.jsp?conid=lvguan&x=616&y=594&timestamp=1185259637625
				String sdStr = getStrBetween(res, "\"/npc/construction.jsp?conid=jinghuazhishendian\",", ")", 0);
				if(sdStr != null) sdParam = "x="+sdStr.replaceFirst(",", "&y=")+"&timestamp=";
				
				// /npc/construction.jsp?conid=lvguan&x=616&y=594&timestamp=1185259637625
				String wzStr = getStrBetween(res, "\"/npc/construction.jsp?conid=wuzizhongxin\",", ")", 0);
				if(wzStr != null) wzParam = "x="+wzStr.replaceFirst(",", "&y=")+"&timestamp=";
				
				logger.info(mDotUser.getLoginId()+"@enter city:("+mUserConf.getRestCityX()+","+mUserConf.getRestCityY()+")");
			}
			sleep(1000);
			
			// sleep
			if(lgParam != null)
			{
				GetMethod gm1 = new GetMethod(mHttpHost+"/npc/construction.jsp?conid=lvguan&"+lgParam+System.currentTimeMillis());
				doRequest(gm1);
				GetMethod gm2 = new GetMethod(mHttpHost+"/home/sleep_in_inn.jsp?conid=lvguan&"+lgParam+System.currentTimeMillis());
				doRequest(gm2);
				logger.info(mDotUser.getLoginId()+"@sleep in hotal");
			}
			sleep(1000);
			
			// purify
			if(sdParam != null)
			{
				GetMethod gm1 = new GetMethod(mHttpHost+"/npc/construction.jsp?conid=jinghuazhishendian&"+sdParam+System.currentTimeMillis());
				doRequest(gm1);
				GetMethod gm2 = new GetMethod(mHttpHost+"/user/deal_clean_rst.jsp?conid=jinghuazhishendian&"+sdParam+System.currentTimeMillis());
				doRequest(gm2);
				logger.info(mDotUser.getLoginId()+"@purify demoned");
			}
			sleep(1000);
			
			// sell
			if(wzParam != null)
			{
				GetMethod gm1 = new GetMethod(mHttpHost+"/npc/construction.jsp?conid=wuzizhongxin&"+wzParam+System.currentTimeMillis());
				doRequest(gm1);
				GetMethod gm2 = new GetMethod(mHttpHost+"/nation/itemshop_sell.jsp?conid=wuzizhongxin&"+wzParam+System.currentTimeMillis());
				String res = doRequest(gm2);
				
				Pattern pItem = Pattern.compile("price_in\\[(\\d+)\\]=(\\d+);");
				int start = 0;
				
				Matcher mItem = pItem.matcher(res);
				StringBuffer items = new StringBuffer();
				
				String notSell = mUserConf.getNotsell();
				int sellPrice = mUserConf.getSellPrc();
				int sellcnt = 0;
				
				while(mItem.find(start))
				{
					String id = mItem.group(1);
					int price = Integer.parseInt(mItem.group(2));
					
					if(notSell.indexOf(id)<0 && sellPrice > price)
					{
						items.append(id+"|");
						sellcnt++;
					}
					start = mItem.end();
				}
				sleep(1000);
				// /nation/itemshop_sell_rst.jsp?x=228&y=551&resid=4664|4226|1455|&timestamp=1185259661515
				GetMethod gm3 = new GetMethod(mHttpHost+"/nation/itemshop_sell_rst.jsp?"+wzParam+System.currentTimeMillis()+"&resid="+items);
				doRequest(gm3);
				logger.info(mDotUser.getLoginId()+"@sell count:"+sellcnt);
				
				ChatItem ci = new ChatItem();
				ci.setType(ChatItem.TYPE_NOTICE);
				ci.setRead(false);
				ci.setText("出售了 "+sellcnt+" 个物品.");
				ci.setTime(mSDFhms.format(new Date()));
				mGameContext.addChatRcv(ci);
			}
			sleep(1000);
			// goout cityy
			{
				GetMethod gm = new GetMethod(mHttpHost+"/main/_map.jsp?timestamp="+System.currentTimeMillis());
				doRequest(gm);
				logger.info(mDotUser.getLoginId()+"@gouout city");
			}
			sleep(1000);
			
			mGameContext.addFightCityTime(System.currentTimeMillis() - t);
		}
		catch(Exception e)
		{
			logger.error(mDotUser.getLoginId()+"@failed to do citybiz", e);
		}
	}
	
	public void repair()
	{
		// init magic
		try
		{
			logger.info(mDotUser.getLoginId()+"@repair weapon");
			{
				GetMethod gm = new GetMethod(mHttpHost+"/equip/change_equip.jsp?timestamp="+System.currentTimeMillis());
				doRequest(gm);
			}
			{
				GetMethod gm = new GetMethod(mHttpHost+"/equip/repair_equip_on_body.jsp?timestamp="+System.currentTimeMillis());
				doRequest(gm);
			}
			{
				GetMethod gm = new GetMethod(mHttpHost+"/equip/repair_equip_on_body_rst.jsp?timestamp="+System.currentTimeMillis());
				doRequest(gm);
			}
			
			ChatItem ci = new ChatItem();
			ci.setType(ChatItem.TYPE_NOTICE);
			ci.setRead(false);
			ci.setText("修理装备");
			ci.setTime(mSDFhms.format(new Date()));
			mGameContext.addChatRcv(ci);
			
		}catch(Exception e)
		{
			logger.error(mDotUser.getLoginId()+"@failed to repair weapon", e);
		}
	}
	
	public void fight()
	{
		long t = System.currentTimeMillis();
		
		mGameContext.setStatus(GameContext.STATUS_FIGHT);
		try 
		{
			// init fight
			int posX = mGameContext.getUserX() - mDotMap.getMapX();
			int posY = mGameContext.getUserY() - mDotMap.getMapY();
			
			if(mUserConf.isMapRandom())
			{
				int index = mDotMap.getRandomMap(mUserConf.getMapType());
				posX = index % DotMap.MAP_TYPE_MATRIX;
				posY = index / DotMap.MAP_TYPE_MATRIX;
				
				mGameContext.setUserX(posX+mDotMap.getMapX());
				mGameContext.setUserY(posY+mDotMap.getMapY());
			}
			
			logger.info(mDotUser.getLoginId()+"@init fight,("+posX+","+posY+")");
			{
				GetMethod gm = new GetMethod(mHttpHost+"/fight/fight_demoninit.jsp?x=" 
						+ posX 
						+ "&y="+ posY
						+ "&demonstep=" + (mGameContext.getFightStep()+mRandom.nextInt(10)) 
						+ "&ac="+mGameContext.getFightAc());
				
				doRequest(gm);
			}
			sleep(1000);
			
			// fight
			String[] attacks =  mUserConf.getAttack();
			String timeToken = ">start(";
			boolean isFighting = true;
			int fightCnt = 0;
			while(isFighting)
			{
				for (int i = 0; i < attacks.length; i++) 
				{
					if(!isFighting) break;
					
					String url = mHttpHost+"/fight/fight_attack.jsp?timestamp="+System.currentTimeMillis();
					if(!"physical".equals(attacks[i]))
					{
						url = mHttpHost+"/fight/fight_perform.jsp?per="+attacks[i]+"&timestamp="+System.currentTimeMillis();
					}
					GetMethod gm = new GetMethod(url);
					String rsp = doRequest(gm);
					String time = getStrBetween(rsp, timeToken, ")", 0);
					
					//dump(gm);
					long attackIdle =  mUserConf.getAttackIdle();
					
					if(time != null)
					{
						try
						{
							attackIdle = Long.parseLong(time);
							fightCnt++;
							//logger.info(mDotUser.getLoginId()+"@attack: "+attacks[i]+" , sleep:"+time);
						}
						catch(Exception e)
						{
							logger.error(mDotUser.getLoginId()+"@wrong sleep time:"+attackIdle);
						}
					}
					else 
					{
						if(rsp.indexOf("parent.gameover")>0)
						{
							isFighting = false;
							logger.info(mDotUser.getLoginId()+"@fight over,attacked count:"+fightCnt);
							break;
						}
						else
						{
							GetMethod gm1 = new GetMethod(mHttpHost+"/fight/fight_surrender.jsp?timestamp="+System.currentTimeMillis());
							doRequest(gm1);
							isFighting = false;
							logger.warn(mDotUser.getLoginId()+"@unkonw respone and escape,count:"+fightCnt);
							
							ChatItem ci = new ChatItem();
							ci.setType(ChatItem.TYPE_NOTICE);
							ci.setRead(false);
							ci.setText("返回值无法解析,尝试逃跑.");
							ci.setTime(mSDFhms.format(new Date()));
							mGameContext.addChatRcv(ci);
						}
						
						//mGameContext.setFightOver(true); // 等错误页(有点暴力了)
						
//						while(!mGameContext.isFightOver()) sleep(1000);//等服务器端发结束信息(太慢了,还有问题)
//						System.exit(0);
//						break;
					}
					if(attackIdle < mUserConf.getAttackIdle()) attackIdle = mUserConf.getAttackIdle();
					
					if(attackIdle > 0 ) sleep(attackIdle);
				}
			}
			
			// load result
			{
//				logger.info(mDotUser.getLoginId()+"@load fight result");
				GetMethod gm = new GetMethod(mHttpHost+"/fight/loadresult.jsp?timestamp="+System.currentTimeMillis());
				String rsp = doRequest(gm);
				rsp = iso2Gbk(rsp);
				parseDotUser(rsp);
				logger.info(mDotUser.getLoginId()+"@parsed fight result,killed count:"+(mDotUser.getKilled()+1));
				
				mDotUser.addKilled();
			}
			long kt = System.currentTimeMillis() - t;
			
			int secper = (int)kt / 1000;
			if(mGameContext.getFightSecPer() != 0)
			{
				secper = (secper+mGameContext.getFightSecPer())/2;
			}
			
			int killper = fightCnt;
			if(mGameContext.getFightKillPer() != 0)
			{
				killper = (killper+mGameContext.getFightKillPer())/2;
			}
			
			mGameContext.setFightKillPer(killper);
			mGameContext.setFightSecPer(secper);
			mGameContext.addFightKillTime(kt);
			
		} catch (Exception e) 
		{
			logger.error(mDotUser.getLoginId()+"@failed to fight", e);
			mGameContext.setStatus(GameContext.STATUS_ERROR);
		}
	}
	
	
	private void initMagic(String str)
	{
		Pattern pMagic = Pattern.compile("magic_name\\[\"(.+)\"\\] = \"(.+)\";");
		int start = 0;
		
		Map magic = new HashMap();
		
		Magic physical = new Magic();
		physical.setId("physical");
		physical.setName("纯物理攻击");
		physical.setMp("0");
		
		magic.put(physical.getId(), physical);
		
		Matcher mMagic = pMagic.matcher(str);
		while(mMagic.find(start))
		{
			String forbidToken = "magic_forbid[\""+mMagic.group(1)+"\"] = false";
			String mpToken = "magic_mp[\""+mMagic.group(1)+"\"] = ";
			if(str.indexOf(forbidToken,start) > 0)
			{
				Magic m = new Magic();
				m.setId(mMagic.group(1));
				m.setName(mMagic.group(2));
				
				String mp = getStrBetween(str, mpToken, ";", start);
				m.setMp(mp);
				
				magic.put(m.getId(), m);
			}
			start = mMagic.end();
		}
		
		mGameContext.setMagicMap(magic);
	}
	
	private void initFight(String str)
	{
		
		String acToken = "_=";
		String acStr = getStrBetween(str,acToken,";",0);
		if(acStr != null)
		{
			logger.info(mDotUser.getLoginId()+"@fight ac:"+acStr);
			mGameContext.setFightAc(acStr);
		}
		
		String stepToken = "DEMON_STEP_MEET = ";
		String stepStr = getStrBetween(str,stepToken,";",0);
		if(stepStr == null)
		{
			mGameContext.setFightStep(40);
		}
		else
		{
			mGameContext.setFightStep(Integer.parseInt(stepStr));
		}
		
	}
	
	private void parseDotUser(String str)
	{
		String statusToken = "top.status_refresh(";
		String statusStr = getStrBetween(str,statusToken,")",0);
		if(statusStr != null)
		{
			String[] status = statusStr.split(",");
			mDotUser.setHpNow(Integer.parseInt(status[0]));
			mDotUser.setHpMax(Integer.parseInt(status[1]));
			mDotUser.setMpNow(Integer.parseInt(status[2]));
			mDotUser.setMpMax(Integer.parseInt(status[3]));
			mDotUser.setEpNow(Integer.parseInt(status[4]));
			mDotUser.setEpMax(Integer.parseInt(status[5]));
			mDotUser.setMoney(Integer.parseInt(status[6]));
		}
		
		
		String bagToken = "status_itemnum_refresh(";
		String bagsStr = getStrBetween(str,bagToken,")",0);
		if(bagsStr != null)
		{
			String[] bags = bagsStr.split(",");
			mDotUser.setBagNow(Integer.parseInt(bags[0]));
			mDotUser.setBagMax(Integer.parseInt(bags[1]));
		}
		
		String apToken = "status_apinfo_refresh(";
		String apsStr = getStrBetween(str,apToken,")",0);
		if(apsStr != null)
		{
			String[] aps = apsStr.split(",");
			mDotUser.setApFree(Integer.parseInt(aps[0].trim()));
			mDotUser.setApMax(Integer.parseInt(aps[1].trim()));
			mDotUser.setExpNow(Integer.parseInt(aps[2].trim()));
			mDotUser.setExpMax(Integer.parseInt(aps[3].trim()));
		}
		
		String binfoToken = "status_userbaseinfo_refresh(";
		String binfosStr = getStrBetween(str,binfoToken,")",0);
		if(binfosStr != null)
		{
			String[] binfos = binfosStr.split(",");
			mDotUser.setGameId(getStrBetween(binfos[0],"\"","\"",0));
			mDotUser.setGameName(getStrBetween(binfos[1],"\"","\"",0));
			mDotUser.setTribe(getStrBetween(binfos[3],"\"","\"",0));
			mDotUser.setMale(binfos[4].indexOf("female")<0);
			mDotUser.setCountry(getStrBetween(binfos[13],"\"","\"",0));
		}
		
		String einfoToken = "status_userbaseinfo2_refresh(";
		String einfosStr = getStrBetween(str,einfoToken,")",0);
		if(einfosStr != null)
		{
			String[] einfos = einfosStr.split(",");
			mDotUser.setStrNow(Integer.parseInt(einfos[0].trim()));
			mDotUser.setStrMax(Integer.parseInt(einfos[1].trim()));
			mDotUser.setRstNow(Integer.parseInt(einfos[2].trim()));
			mDotUser.setRstMax(Integer.parseInt(einfos[3].trim()));
			mDotUser.setDexNow(Integer.parseInt(einfos[4].trim()));
			mDotUser.setDexMax(Integer.parseInt(einfos[5].trim()));
			mDotUser.setActNow(Integer.parseInt(einfos[6].trim()));
			mDotUser.setActMax(Integer.parseInt(einfos[7].trim()));
			mDotUser.setIntlNow(Integer.parseInt(einfos[8].trim()));
			mDotUser.setIntlMax(Integer.parseInt(einfos[9].trim()));
			mDotUser.setChmNow(Integer.parseInt(einfos[10].trim()));
			mDotUser.setChmMax(Integer.parseInt(einfos[11].trim()));
			mDotUser.setWlpNow(Integer.parseInt(einfos[12].trim()));
			mDotUser.setWlpMax(Integer.parseInt(einfos[13].trim()));
			mDotUser.setSvyNow(Integer.parseInt(einfos[14].trim()));
			mDotUser.setSvyMax(Integer.parseInt(einfos[15].trim()));
			
			mDotUser.setDemoned(Integer.parseInt(einfos[16].trim()));
			mDotUser.setApstore(Integer.parseInt(einfos[17].trim()));
		}
	}
	
	private void parseDotMap(String str)
	{
		// decoding
		str = iso2Gbk(str);
		
		// position
		String mapXToken  = "parent.now_map_x = ";
		String mapYToken  = "parent.now_map_y = ";
		String userXToken = "var tpx = ";
		String userYToken = "var tpy = ";
		
		int mapX = Integer.parseInt(getStrBetween(str,mapXToken,";",0));
		int mapY = Integer.parseInt(getStrBetween(str,mapYToken,";",0));
		mDotMap = new DotMap(mapX,mapY);
		
		int userX = Integer.parseInt(getStrBetween(str,userXToken,";",0));
		int userY = Integer.parseInt(getStrBetween(str,userYToken,";",0));
		mGameContext.setUserX(userX);
		mGameContext.setUserY(userY);
		
		// mapTypeToken
		String mapTypeToken = "terrainList = new Array(";
		String mapType = getStrBetween(str,mapTypeToken,")",0);
		mDotMap.initMapTypes(mapType);
		
		// city
		String cityToken = "parent.struct_nationinfo";
		String cityNameToken = "oneNation.name=\"";
		String cityKingIdToken = "oneNation.king_id=\"";
		String cityKingNameToken = "oneNation.king_name=\"";
		String cityXToken = "oneNation.palace_posx=";
		String cityYToken = "oneNation.palace_posy=";
		String cityTownToken = "oneNation.block_num=";
		String cityCitizenToken = "oneNation.citizen_num=";
		String citySoldierToken = "oneNation.soldier_num=";
		String cityMoneyToken = "oneNation.money=";
		
		int cs = str.indexOf(cityToken);
		while (cs > 0)
		{
			String cityName 	= getStrBetween(str,cityNameToken,"\";",cs);
			String cityKingId 	= getStrBetween(str,cityKingIdToken,"\";",cs);
			String cityKingName = getStrBetween(str,cityKingNameToken,"\";",cs);
			String cityX 		= getStrBetween(str,cityXToken,";",cs);
			String cityY 		= getStrBetween(str,cityYToken,";",cs);
			String cityTown 	= getStrBetween(str,cityTownToken,";",cs);
			String cityCitizen  = getStrBetween(str,cityCitizenToken,";",cs);
			String citySoldier  = getStrBetween(str,citySoldierToken,";",cs);
			String cityMoney 	= getStrBetween(str,cityMoneyToken,";",cs);
			
			MapCity mc = new MapCity();
			mc.setName(cityName);
			mc.setKingId(cityKingId);
			mc.setKingName(cityKingName);
			mc.setMapX(Integer.parseInt(cityX));
			mc.setMapY(Integer.parseInt(cityY));
			mc.setTownCnt(Integer.parseInt(cityTown));
			mc.setCitizenCnt(Integer.parseInt(cityCitizen));
			mc.setSoldierCnt(Integer.parseInt(citySoldier));
			mc.setMoney(Integer.parseInt(cityMoney));
			mc.setWorldX(mc.getMapX()+mDotMap.getMapX());
			mc.setWorldX(mc.getMapY()+mDotMap.getMapY());
			
			mDotMap.addCity(mc);
			logger.info(mDotUser.getLoginId()+"@add city:"+cityX+","+cityY);
			cs = str.indexOf(cityToken,cs+cityToken.length());
		}
		
		// town
		String townToken = "parent.struct_event(xy(";
		int ts = str.indexOf(townToken);
		while(ts>0)
		{
			String xy = getStrBetween(str,townToken,")",ts);
			String[] ps = xy.split(",");
			mDotMap.addTown(Integer.parseInt(ps[0]), Integer.parseInt(ps[1]));
			ts = str.indexOf(townToken,ts+townToken.length());
			logger.info(mDotUser.getLoginId()+"@add town:"+xy);
		}
		
		// other user
		Pattern pName  = Pattern.compile("PP\\[\"(.+)\"\\]\\[\"name\"\\]=\"(.+)\";");
		Pattern pTribe = Pattern.compile("PP\\[\"(.+)\"\\]\\[\"tribe\"\\]=\"(.+)\";");
		Pattern pSex = Pattern.compile("PP\\[\"(.+)\"\\]\\[\"sex\"\\]=\"(\\d+)\";");
		
		Matcher mName  = pName.matcher(str);
		Matcher mTribe = pTribe.matcher(str);
		Matcher mSex   = pSex.matcher(str);
		
		int start = 0;
		if(mName.find(start))
		{
			MapUser mu = new MapUser();
			mu.setId(mName.group(1));
			mu.setName(mName.group(2));
			
			if(mTribe.find(start)) mu.setTribe(mTribe.group(2));
			if(mSex.find(start)) mu.setMale("0".equals(mSex.group(2)));
			
			mGameContext.addMapUser(mu);
			start = mName.end();
		}
	}
	private void dump(HttpMethodBase m)
	{
		if(m == null) return;
		
		StringBuffer sb = new StringBuffer();
		sb.append(m.getPath()+"?"+m.getQueryString());
		sb.append("\n========= request headers =========");
		Header[] hs1 =m.getRequestHeaders();
		for (int i = 0; i < hs1.length; i++) 
		{
			sb.append("\n").append(hs1[i].getName()).append("=").append(hs1[i].getValue());
		}
		sb.append("\n========= response headers =========");
		Header[] hs2 =m.getResponseHeaders();
		for (int i = 0; i < hs2.length; i++) 
		{
			sb.append("\n").append(hs2[i].getName()).append("=").append(hs2[i].getValue());
		}
		sb.append("\n========= response body =========\n");
		
		
		FileOutputStream fos = null;
		try 
		{
			String fn = mDotUser.getLoginId()+"_"+m.getName()
				+m.getPath().replaceAll("/", "_")
				+mSDFymdhms.format(new Date())
				+".htm";
			fos = new FileOutputStream("./htm/"+fn);
			fos.write(("<pre>"+sb.toString()+"</pre>").getBytes());
			
			InputStream is = m.getResponseBodyAsStream();
			if(is != null)
			{
				byte[] b = new byte[1024];
				int r = is.read(b);
				while(r>0)
				{
					fos.write(b,0,r);
					r = is.read(b);
				}
				is.close();
			}
		}
		catch (Exception e) 
		{
			logger.error("faile to dump "+m,e);
		}
		finally
		{
			try 
			{
				if(fos != null)	fos.close();
			} catch (IOException e) {
			}
		}
		
	}
	private void fakeMethodHeader(HttpMethodBase m)
	{
		m.getParams().setCookiePolicy(CookiePolicy.BROWSER_COMPATIBILITY);
		m.setRequestHeader("Accept", "*/*");
		m.setRequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)");
		m.setRequestHeader("Connection", "Keep-Alive");
	}
	
	private String gbk2Iso(String str)
	{
		String r = str;
		try{
			r = new String(str.getBytes("GBK"),"ISO8859-1");
		}catch (Exception e){}
		return r;
	}
	private String iso2Gbk(String str)
	{
		String r = str;
		try{
			r = new String(str.getBytes("ISO8859-1"),"GBK");
		}catch (Exception e){}
		return r;
	}
	
	private String doRequest(HttpMethodBase hm) throws Exception
	{
		String r = null;
		try 
		{
			fakeMethodHeader(hm);
			int statusCode = mHttpClient.executeMethod(hm);
			if (statusCode != HttpStatus.SC_OK) 
			{
				throw new HttpException("http code error:"+statusCode+",should be "+HttpStatus.SC_OK);
			}
			else
			{
				r = hm.getResponseBodyAsString();
			}
			
			if(mSysInfo != null)
			{
				int snd = 0;
				int rcv = 0;
				
				Header hsnd = hm.getRequestHeader("Content-Length");
				if(hsnd != null)
				{
					snd = Integer.parseInt(hsnd.getValue());
				}
				else
				{
					snd = 400;
				}
				
				Header hrcv = hm.getResponseHeader("Content-Length");
				if(hrcv != null)
				{
					rcv = Integer.parseInt(hrcv.getValue());
				}
				else
				{
					rcv = r==null?500:r.length();
				}
				
				mSysInfo.addSndByte(snd);
				mSysInfo.addRcvByte(rcv);
			}
			
		}
		catch (Exception e) 
		{
			dump(hm);
			logger.error(mDotUser.getLoginId()+"@failed to do request", e);
			throw e;
		}
		finally
		{
			if(hm != null)
			{
				hm.releaseConnection();
			}
		}
		
		return r;
	}
	
	private String getStrBetween(String str, String s1,String s2,int start)
	{
		String r = null;
		int p1 = str.indexOf(s1,start);
		if(p1 >= 0)
		{
			int pa = p1+s1.length();
			int p2 = str.indexOf(s2,pa);
			if(p2 > p1)
			{
				r = str.substring(pa, p2);
			}
		}
		return r;
	}
	
	private class ScriptReceiver extends Thread
	{
		private Pattern pChat = Pattern.compile("parent\\.chat_say\\(\"(\\d+)\",(\\d),\"(.+)\",\"(.+)\",\".+\",\"(.+)\",.+,\"(.+)\"\\);");
		// id,name,tribe,sex,index,mapx,mapy,x,y,ride)
		private Pattern pEnter = Pattern.compile("top\\.game\\.gamewindow\\.usermove_w_enter\\('(.+)','(.+)','(.+)',(\\d+),\\d+,(\\d+),(\\d+),\\d+,\\d+,.+\\)");
		private Pattern pLeave = Pattern.compile("top\\.game\\.gamewindow\\.usermove_w_leave\\('(.+)',(\\d+),(\\d+),(\\d+),(\\d+)\\)");
		private Pattern pFightOver = Pattern.compile("evt\\.type=(\\d+);");
		private Pattern chatRpl1 = Pattern.compile("<font color=#.{6}>");
		private Pattern chatRpl2 = Pattern.compile("</font>");
		private Pattern partSpter = Pattern.compile("</script>");
		private String  partToken = "</script>";
		
		private volatile boolean toStop = false;
		private volatile boolean stoped = true;
		private URL     chatURL = null;
		private String charset = "GB2312";

		public void setChatURL(URL url)
		{
			chatURL = url;
		}
		
		private boolean isStoped()
		{
			return stoped;
		}
		
		public void close()
		{
			toStop = true;
		}
		public void run()
		{
			logger.info(mDotUser.getLoginId()+"@chat client start");

			StringBuffer sb = new StringBuffer();
			char[] buffer = new char[512];
			
			URLConnection cc = null;
			InputStreamReader  isr  = null;
			try {
				cc = chatURL.openConnection();
				isr = new InputStreamReader(cc.getInputStream(),charset);
			} catch (IOException e) {
				logger.error(mDotUser.getLoginId()+"@failed to connect chat server", e);
			}
			toStop = false;
			stoped = false;
			//
			while(!toStop)
			{
				try 
				{
					if(isr.ready())
					{
						int r = isr.read(buffer);
						if(r > 0)
						{
							if(mSysInfo != null)
							{
								mSysInfo.addRcvByte((long)(r*1.2));
							}
							
							sb.append(buffer, 0, r);
							//
							int lpos = sb.lastIndexOf(partToken);
							if(lpos > 0 )
							{
								String chat = sb.substring(0, lpos);
								sb.delete(0, lpos);
								doScript(chat);
							}
						}
					}
					//
					try {
						sleep(500);
					} catch (InterruptedException e) {
					}
				} catch (IOException e) 
				{
					logger.error(mDotUser.getLoginId()+"@chat client down",e);
				}
			}
			//
			try 
			{
				isr.close();
			}
			catch (IOException e) 
			{
				logger.error(mDotUser.getLoginId()+"@failed to close chat client");
			}
			stoped = true;
		}
		
		private void doScript(String str)
		{
			if(str == null || str.length() == 0) return;
			
			str = chatRpl1.matcher(str).replaceAll("");
			str = chatRpl2.matcher(str).replaceAll("");
			String[] strs = partSpter.split(str);
			
			for (int i = 0; i < strs.length; i++)
			{
				if(strs[i].length() == 0) continue;
				
				// chat
				Matcher mChat = pChat.matcher(strs[i]);
				if(mChat.find())
				{
					ChatItem ci = new ChatItem();
					
					String id = mChat.group(3);
					ci.setUserid(id);
					ci.setMale("MALE".equalsIgnoreCase(mChat.group(6)));
					ci.setRead(false);
					ci.setText(mChat.group(5));
					ci.setUsername(mChat.group(4));
					ci.setTime(mSDFhms.format(new Date()));
					
					if(mGameContext.isChatWorldChannel(mChat.group(1)))
						ci.setType(ChatItem.TYPE_WORLD);
					else if(mGameContext.isChatCountryChannel(mChat.group(1)))
						ci.setType(ChatItem.TYPE_COUNTRY);
					else 
					{
						if("0".equals(mChat.group(2)))
						{
							ci.setType(ChatItem.TYPE_PRIVATE);
							mGameContext.addChatPrivateChannel(id, mChat.group(1));
						}
						else if ("1".equals(mChat.group(2)))
						{
							ci.setType(ChatItem.TYPE_GROUP);
							mGameContext.addChatGroupChannel(id, mChat.group(1));
						}
						else if ("3".equals(mChat.group(2)))
							ci.setType(ChatItem.TYPE_SYSTEM);
						else
							ci.setType(ChatItem.TYPE_UNKNOWN);
					}
					
					mGameContext.addChatRcv(ci);
					
					continue;
				}
				
				// enter
				Matcher mEnter = pEnter.matcher(strs[i]);
				if(mEnter.find())
				{
					int mapX = Integer.parseInt(mEnter.group(5));
					int mapY = Integer.parseInt(mEnter.group(6));
					
					if(mDotMap.isNowMap(mapX, mapY))
					{
						MapUser mu = new MapUser();
						mu.setId(mEnter.group(1));
						mu.setName(mEnter.group(2));
						mu.setTribe(mEnter.group(3));
						mu.setMale("0".equals(mEnter.group(4)));
						mGameContext.addMapUser(mu);
						
						ChatItem ci = new ChatItem();
						ci.setType(ChatItem.TYPE_NOTICE);
						ci.setRead(false);
						ci.setText(mu.getName()+"("+mu.getId()+") "+(mu.isMale()?"男":"女")+" 进入本地图");
						ci.setTime(mSDFhms.format(new Date()));
						mGameContext.addChatRcv(ci);
					}
					
					continue;
				}
				
				Matcher mLeave = pLeave.matcher(strs[i]);
				if(mLeave.find())
				{
					String id = mLeave.group(1);
					int mapX = Integer.parseInt(mLeave.group(2));
					int mapY = Integer.parseInt(mLeave.group(3));
					
					if(mDotMap.isNowMap(mapX, mapY))
					{
						MapUser mu = mGameContext.delMapUser(id);
						
						if(mu != null)
						{
							ChatItem ci = new ChatItem();
							ci.setType(ChatItem.TYPE_NOTICE);
							ci.setRead(false);
							ci.setText(mu.getName()+"("+mu.getId()+") "+(mu.isMale()?"男":"女")+" 离开本地图");
							ci.setTime(mSDFhms.format(new Date()));
							mGameContext.addChatRcv(ci);
						}
					}
					
					continue;
				}
				
				Matcher mFightOver = pFightOver.matcher(strs[i]);
				if(mFightOver.find())
				{
//					//TODO
//					if("4".equals(mFightOver.group(1)))
//					{
//						mGameContext.setFightOver(true);
////						ChatItem ci = new ChatItem();
////						ci.setType(ChatItem.TYPE_NOTICE);
////						ci.setRead(false);
////						ci.setText("杀死了一个怪怪:)");
////						ci.setTime(dateFormat.format(new Date()));
////						mGameContext.addChatRcv(ci);
//					}
					
					continue;
				}
				
				// others
				logger.info(mDotUser.getLoginId()+"@[8080] script:"+strs[i]);
			}
		}
	}
	
	public boolean isLogined()
	{
		return !needLogin;
	}
	
	public static void main(String[] args) throws Exception 
	{
		PropertyConfigurator.configure("res/cnf/log4j.properties");
		
		UserConf du = new UserConf();
		du.setLoginId("");
		du.setPasswd("");
		du.setServer(1);
		du.setWorld(1);
		du.setProxy(false);

		GameClient gc = new GameClient(du);
		gc.login();
	}
}
