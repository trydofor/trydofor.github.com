package com.trydofor.game.dot.test;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CharTest {

	public static final Pattern htmPattern = Pattern.compile("&#(\\d+);");
	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		String str = "好ihaoa &#63;";
		Matcher m = htmPattern.matcher(str);
		int pos = 0;
		while(m.find(pos))
		{
			int code = Integer.parseInt(m.group(1));
			str = str.replaceAll(m.group(), String.valueOf((char)code));
			pos = m.end();
		}
		System.out.println(str);

	}

}
