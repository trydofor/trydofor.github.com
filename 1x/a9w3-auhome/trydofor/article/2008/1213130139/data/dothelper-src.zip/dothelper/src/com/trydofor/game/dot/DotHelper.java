package com.trydofor.game.dot;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.Vector;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import com.trydofor.game.dot.biz.GameClient;
import com.trydofor.game.dot.gui.DlgMain;
import com.trydofor.game.dot.udt.SysInfo;
import com.trydofor.game.dot.udt.UserConf;
public class DotHelper
{
	private static final Logger logger   = Logger.getLogger(DotHelper.class);
	
	private static final String confToken = "user_";
	
	private static Properties   defaultConf = new Properties();
	private static Map			mClientMap  = new HashMap();
	private static UserConf		userConf    = new UserConf();
	private static SysInfo		sysInfo		= new SysInfo(); 
	private static boolean      isStop = false;
	
	private DotHelper() 
	{
	}

	
	private static void initLog()
	{
		PropertyConfigurator.configure("res/cnf/log4j.properties");
	}
	
	private static void initConf() throws IOException
	{
		defaultConf.load(new FileInputStream("res/cnf/dothelper.properties"));
		userConf.setUrl(defaultConf.getProperty("url"));
		userConf.setServer(paserInt(defaultConf.getProperty("server"),1));
		userConf.setWorld(paserInt(defaultConf.getProperty("world"),1));
		userConf.setAttack(defaultConf.getProperty("attack").split(","));
		userConf.setPkmode(defaultConf.getProperty("pkmode"));
		userConf.setProxy("true".equals(defaultConf.getProperty("proxy")));
		userConf.setProxyHost(defaultConf.getProperty("proxy.host"));
		userConf.setProxyPort(paserInt(defaultConf.getProperty("proxy.port"),0));
		userConf.setNotsell(defaultConf.getProperty("notsell"));
		userConf.setSellBag(paserInt(defaultConf.getProperty("sellbag"),80));
		userConf.setSleepHp (paserInt(defaultConf.getProperty("sleephp"),50));
		userConf.setSleepMp (paserInt(defaultConf.getProperty("sleepmp"),50));
		userConf.setRepair(paserInt(defaultConf.getProperty("repair"),20));
		userConf.setPurify(paserInt(defaultConf.getProperty("purify"),0));
		userConf.setMapRandom("true".equals(defaultConf.getProperty("maprandom")));
		
		userConf.setSellPrc(paserInt(defaultConf.getProperty("sellprice"),1000));
		userConf.setLoginIdle(paserInt(defaultConf.getProperty("loginidle"),60));
		userConf.setCityIdle(paserInt(defaultConf.getProperty("cityidle"),10));		
		userConf.setFightIdle(paserInt(defaultConf.getProperty("fightidle"),5));	
		userConf.setAttackIdle(paserInt(defaultConf.getProperty("attackidle"),1000));	
		
		String[] cityXY = defaultConf.getProperty("restcity").split(",");
		userConf.setRestCityX(Integer.parseInt(cityXY[0]));
		userConf.setRestCityY(Integer.parseInt(cityXY[1]));
		
		String[] mtstrs = defaultConf.getProperty("maptype").split(",");
		int[] mts = new int[mtstrs.length];
		for (int i = 0; i < mts.length; i++) {
			mts[i] = Integer.parseInt(mtstrs[i]);
		}
		userConf.setMapType(mts);
	}
	
	private static void startClient(File config,String loginId)
	{
		try
		{
		Properties up = new Properties();
		up.load(new FileInputStream(config));
		
		UserConf uc = new UserConf();
		uc.setLoginId(loginId);
		uc.setPasswd(up.getProperty("passwd"));
		uc.setUrl(userConf.getUrl());
		//
		String server = up.getProperty("server");
		if(server != null && !"".equals(server))
			uc.setServer(Integer.parseInt(server));
		else
			uc.setServer(userConf.getServer());
		
		String world = up.getProperty("world");
		if(world != null && !"".equals(world))
			uc.setWorld(Integer.parseInt(world));
		else
			uc.setWorld(userConf.getWorld());
		
		String attack = up.getProperty("attack");
		if(attack != null && !"".equals(attack))
			uc.setAttack(attack.split(","));
		else
			uc.setAttack(userConf.getAttack());

		String pkmode = up.getProperty("pkmode");
		if(pkmode != null && !"".equals(pkmode))
			uc.setPkmode(pkmode);
		else
			uc.setPkmode(userConf.getPkmode());
		
		String proxy = up.getProperty("proxy");
		if(proxy != null && !"".equals(proxy))
			uc.setProxy("true".equals(proxy));
		else
			uc.setProxy(userConf.isProxy());

		String proxyHost = up.getProperty("proxy.host");
		if(proxyHost != null && !"".equals(proxyHost))
			uc.setProxyHost(proxyHost);
		else
			uc.setProxyHost(userConf.getProxyHost());
		
		String proxyPort = up.getProperty("proxy.port");
		if(proxyPort != null && !"".equals(proxyPort))
			uc.setProxyPort(Integer.parseInt(proxyPort));
		else
			uc.setProxyPort(userConf.getProxyPort());				
		
		String notsell = up.getProperty("notsell");
		if(notsell != null && !"".equals(notsell))
			uc.setNotsell(notsell);
		else
			uc.setNotsell(userConf.getNotsell());
		
		String sellbag = up.getProperty("sellbag");
		if(sellbag != null && !"".equals(sellbag))
			uc.setSellBag(paserInt(sellbag,userConf.getSellBag()));
		else
			uc.setSellBag(userConf.getSellBag());
		
		String sleephp = up.getProperty("sleephp");
		if(sleephp != null && !"".equals(sleephp))
			uc.setSleepHp(paserInt(sleephp,userConf.getSleepHp()));
		else
			uc.setSleepHp(userConf.getSleepHp());

		String sleepmp = up.getProperty("sleepmp");
		if(sleepmp != null && !"".equals(sleepmp))
			uc.setSleepMp(paserInt(sleepmp,userConf.getSleepMp()));
		else
			uc.setSleepMp(userConf.getSleepMp());

		String repair = up.getProperty("repair");
		if(repair != null && !"".equals(repair))
			uc.setRepair(paserInt(repair,userConf.getRepair()));
		else
			uc.setRepair(userConf.getRepair());
		
		String purify = up.getProperty("purify");
		if(purify != null && !"".equals(purify))
			uc.setPurify(paserInt(purify,userConf.getPurify()));
		else
			uc.setPurify(userConf.getPurify());
		
		String maprandom = up.getProperty("maprandom");
		if(maprandom != null && !"".equals(maprandom))
			uc.setMapRandom("true".equals(maprandom));
		else
			uc.setMapRandom(userConf.isMapRandom());
		
		String maptype = up.getProperty("maptype");
		if(maptype != null && !"".equals(maptype))
		{
			String[] mtstrs = maptype.split(",");
			int[] mts = new int[mtstrs.length];
			for (int j = 0; j < mts.length; j++) {
				mts[j] = Integer.parseInt(mtstrs[j]);
			}
			uc.setMapType(mts);
		}
		else
		{
			uc.setMapType(userConf.getMapType());
		}
		
		String sellprice = up.getProperty("sellprice");
		if(sellprice != null && !"".equals(sellprice))
			uc.setSellPrc(paserInt(sellprice,1000));
		else
			uc.setSellPrc(userConf.getSellPrc());
		
		String restcity = up.getProperty("restcity");
		if(restcity != null && !"".equals(restcity))
		{
			String[] cityXY = restcity.split(",");
			uc.setRestCityX(Integer.parseInt(cityXY[0]));
			uc.setRestCityY(Integer.parseInt(cityXY[1]));
		}
		else
		{
			uc.setRestCityX(userConf.getRestCityX());
			uc.setRestCityY(userConf.getRestCityY());
		}

		String loginidle = up.getProperty("loginidle");
		if(loginidle != null && !"".equals(loginidle))
			uc.setLoginIdle(paserInt(loginidle,60));
		else
			uc.setLoginIdle(userConf.getLoginIdle());
		
		String cityidle = up.getProperty("cityidle");
		if(cityidle != null && !"".equals(cityidle))
			uc.setCityIdle(paserInt(cityidle,10));
		else
			uc.setCityIdle(userConf.getCityIdle());
		
		String fightidle = up.getProperty("fightidle");
		if(fightidle != null && !"".equals(fightidle))
			uc.setFightIdle(paserInt(fightidle,5));
		else
			uc.setFightIdle(userConf.getFightIdle());
		
		String attackidle = up.getProperty("attackidle");
		if(attackidle != null && !"".equals(attackidle))
			uc.setAttackIdle(paserInt(attackidle,1000));
		else
			uc.setAttackIdle(userConf.getAttackIdle());
		
		//
		GameClient gc =  new GameClient(uc);
		gc.setSysInfo(sysInfo);
//		gc.start();
		mClientMap.put(uc.getLoginId(), gc);
		}
		catch(Exception e)
		{
			logger.error("failed to start client:"+loginId,e);
		}
	}
	
	private static void initGui()
	{
		Display display = new Display();
		display.setWarnings(false);
		Shell shell = new Shell(display);
		DlgMain dlgMain = new DlgMain(shell, SWT.NULL);
		dlgMain.open();
	}
	
	private static int paserInt(String str,int i)
	{
		if(str == null || str.length() == 0)
		return i;
		
		if(str.endsWith("%"))
			str = str.substring(0, str.length()-1).trim();
		
		int r = i;
		try
		{
			r = Integer.parseInt(str);
		}
		catch(Exception e)
		{
			logger.error("failed to get Int:"+str, e);
		}
		
		return r;
		
	}
	
	public static void stop(GameClient gc)
	{
		if(gc == null)
		{
			gc.close();
		}
		else
		{
			isStop = true;
			for (Iterator iter = mClientMap.values().iterator(); iter.hasNext();) 
			{
				GameClient gc1 = (GameClient) iter.next();
				gc1.close();
			}
		}
	}
	
	public static Map getGameClientMap()
	{
		return mClientMap;
	}
	
	public static void main(String[] args) 
	{
		try 
		{
			initLog();
			logger.info("dothelper start");
			initConf();
			
			isStop = false;
			new Thread()
			{
				public void run()
				{
					while(!isStop)
					{
						File userCnfDir = new File("res/cnf");
						File[] userCnfs = userCnfDir.listFiles();
						Vector  userCnfVector = new Vector();
						
						// start new client
						for(int i=0;i<userCnfs.length;i++)
						{
							if(userCnfs[i].getName().startsWith(confToken))
							{
								int beginIndex = confToken.length();
								int endIndex = userCnfs[i].getName().lastIndexOf('.');
								String loginId = userCnfs[i].getName().substring(beginIndex, endIndex);
								
								if(!mClientMap.containsKey(loginId))
								{
									logger.info("start a new client:"+loginId);
									startClient(userCnfs[i],loginId);
								}
								
								userCnfVector.add(loginId);
							}
						}
						
						// stop old client
						for (Iterator iter = mClientMap.values().iterator(); iter.hasNext();) 
						{
							GameClient gc = (GameClient) iter.next();
							String loginId = gc.getDotUser().getLoginId();
							if(!userCnfVector.contains(loginId))
							{
								gc.close();
								logger.info("stop a client:"+loginId);
							}
						}
						
						try {
							sleep(60000);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
						
					}
				}
			}.start();
			
			for(int i=0;i<args.length;i++)
			{
				if(args[i].equals("gui"))
				{
					logger.info("init gui");
					initGui();
					break;
				}
			}
		}
		catch (Exception e) 
		{
			logger.error("dothelper died:", e);
		} finally
		{
			logger.info("dothelper stop");
		}
	}
}
