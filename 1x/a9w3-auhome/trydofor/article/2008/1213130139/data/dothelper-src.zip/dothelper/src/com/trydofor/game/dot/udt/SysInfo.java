package com.trydofor.game.dot.udt;

public class SysInfo 
{
	private long start; 
	private long sndBytes;
	private long rcvBytes;
	
	private Object locker = new Object();
	
	public SysInfo()
	{
		start = System.currentTimeMillis();
	}

	public long getAlive() 
	{
		return System.currentTimeMillis() - start;
	}
	
	public long getRcvBytes() 
	{
		return rcvBytes;
	}
	public long getSndBytes() 
	{
		return sndBytes;
	}

	public int getSndBps()
	{
		long t = getAlive();
		if(t == 0) return 0;
		
		return (int)(sndBytes * 1000 / t);
	}
	public int getRcvBps()
	{
		long t = getAlive();
		if(t == 0) return 0;
		
		return (int)(rcvBytes * 1000 / t);
	}
	
	public void addSndByte(long snd) 
	{
		synchronized(locker)
		{
			this.sndBytes += snd;
		}
	}
	
	public void addRcvByte(long rcv) 
	{
		synchronized(locker)
		{
			this.rcvBytes += rcv;
		}
	}
	
	
}
