package com.trydofor.game.dot.udt;

public class MapUser
{
	private String id;
	private String name;
	private String tribe;
	private boolean male;
	private boolean ride;
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public boolean isMale() {
		return male;
	}
	public void setMale(boolean male) {
		this.male = male;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public boolean isRide() {
		return ride;
	}
	public void setRide(boolean ride) {
		this.ride = ride;
	}
	public String getTribe() {
		return tribe;
	}
	public void setTribe(String tribe) {
		this.tribe = tribe;
	}
	
	
}
