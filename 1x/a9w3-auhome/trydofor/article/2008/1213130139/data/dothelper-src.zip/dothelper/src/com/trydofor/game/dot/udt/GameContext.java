package com.trydofor.game.dot.udt;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class GameContext
{
	public final static int STATUS_ERROR   = -1;
	public final static int STATUS_INIT    = 0;
	public final static int STATUS_LOGIN   = 1;
	public final static int STATUS_LOGOUT  = 2;
	public final static int STATUS_FIGHT   = 3;
	public final static int STATUS_INCITY  = 4;
	public final static int STATUS_PAUSE   = 5;
	public final static int STATUS_STOP    = 6;
	
	private int status = STATUS_INIT;

	// chat
	private int   maxChat = 200;
	private int   newChatPos = 0;
	private String  chatWorldChannel   = "";
	private String  chatCountryChannel = "";
	private Map     chatPrivateChannel = new HashMap();
	private Map     chatGroupChannel   = new HashMap();
	private List    chatRcv  = new ArrayList();

	// dotmap
	private int 		userX = 0;
	private int 		userY = 0;
	private Map   		mapUsers = new HashMap();
	
	// fight
	private String    fightAc = null;
	private int 	  fightStep = 40;
	private int 	  fightSecPer = 0;
	private int 	  fightKillPer = 0;
	private int 	  fightCityPer = 0;
	private long 	  loginTime = 0;
	private long 	  fightKillTime = 0;
	private long 	  fightCityTime = 0;

	// magic
	private Map		 magicMap = new HashMap();
	
	public String getFightAc() {
		return fightAc;
	}
	public void setFightAc(String fightAc) {
		this.fightAc = fightAc;
	}
	public void addChatRcv(ChatItem ci)
	{
		if(ci == null) return;
		synchronized(chatRcv)
		{
			if(chatRcv.size() >= maxChat)
			{
				int rm = maxChat/3;
				for(int i = rm;i>0; i--)
				{
					chatRcv.remove(0);
				}
				if(newChatPos >= rm) newChatPos -=rm;
			}
			
			chatRcv.add(ci);
		}
	}
	public List getAllChatRcv()
	{
		List r = new ArrayList();
		r.addAll(chatRcv);
		return r;
	}
	public List getChatRcv()
	{
		int s = chatRcv.size();
		if(newChatPos >= s) return null;
		
		List r = new ArrayList();
		synchronized(chatRcv)
		{
			for(;newChatPos<s; newChatPos++)
			{
				ChatItem ci = (ChatItem)chatRcv.get(newChatPos);
				ci.setRead(true);
				r.add(ci);
			}
		}
		return r;
	}
	
	public boolean isChatCountryChannel(String c)
	{
		if(c == null) return false;
		return c.equals(chatCountryChannel);
	}
	
	public boolean isChatWorldChannel(String c)
	{
		if(c == null) return false;
		return c.equals(chatWorldChannel);
	}
	
	
	public void addChatPrivateChannel(String id,String c)
	{
		chatPrivateChannel.put(id, c);
	}
	
	public void addChatGroupChannel(String id,String c)
	{
		chatGroupChannel.put(id, c);
	}
	
	public String getChatPrivateChannel(String id)
	{
		return (String)chatPrivateChannel.get(id);
	}
	
	public String getChatGroupChannel(String id)
	{
		return (String)chatGroupChannel.get(id);
	}
	
	public String getChatCountryChannel() {
		return chatCountryChannel;
	}
	public void setChatCountryChannel(String chatCountryChannel) {
		this.chatCountryChannel = chatCountryChannel;
	}
	public String getChatWorldChannel() {
		return chatWorldChannel;
	}
	public void setChatWorldChannel(String chatWorldChannel) {
		this.chatWorldChannel = chatWorldChannel;
	}
	
	public int getStatus() {
		return status;
	}
	public void setStatus(int nowStatus) {
		this.status = nowStatus;
	}
	public int getUserX() {
		return userX;
	}
	public void setUserX(int userX) {
		this.userX = userX;
	}
	public int getUserY() {
		return userY;
	}
	public void setUserY(int userY) {
		this.userY = userY;
	}

	public List getMapUser()
	{
		if(mapUsers.isEmpty()) return null;
		
		List r = new ArrayList();
		synchronized(mapUsers)
		{
			r.addAll(mapUsers.values());
		}
		
		return r;
	}
	
	public void addMapUser(MapUser mu)
	{
		synchronized(mapUsers)
		{
			mapUsers.put(mu.getId(), mu);
		}
	}
	public MapUser delMapUser(String id)
	{
		MapUser mu = null;
		synchronized(mapUsers)
		{
			mu = (MapUser)mapUsers.remove(id);
		}
		
		return mu;
	}
	public int getFightStep() {
		return fightStep;
	}
	
	public void setFightStep(int fightStep) {
		this.fightStep = fightStep;
	}
	
	public Map getMagicMap() {
		return magicMap;
	}
	public void setMagicMap(Map magicMap) {
		this.magicMap = magicMap;
	}
	public int getFightCityPer() {
		return fightCityPer;
	}
	public void setFightCityPer(int fightCityPer) {
		this.fightCityPer = fightCityPer;
	}
	public long getFightCityTime() {
		return fightCityTime;
	}
	public void addFightCityTime(long t)
	{
		fightCityTime += t;
	}
	public void setFightCityTime(long fightCityTime) {
		this.fightCityTime = fightCityTime;
	}
	public int getFightKillPer() {
		return fightKillPer;
	}
	public void setFightKillPer(int fightKillPer) {
		this.fightKillPer = fightKillPer;
	}
	public long getFightKillTime() {
		return fightKillTime;
	}
	public void addFightKillTime(long t)
	{
		fightKillTime += t;
	}
	public void setFightKillTime(long fightKillTime) {
		this.fightKillTime = fightKillTime;
	}
	public long getLoginTime() {
		return loginTime;
	}
	public void setLoginTime(long loginTime) {
		this.loginTime = loginTime;
	}
	public int getFightSecPer() {
		return fightSecPer;
	}
	public void setFightSecPer(int fightSecPer) {
		this.fightSecPer = fightSecPer;
	}
	
	
}