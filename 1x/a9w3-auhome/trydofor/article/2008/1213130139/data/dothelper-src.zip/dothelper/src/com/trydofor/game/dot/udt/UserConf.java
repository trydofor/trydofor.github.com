package com.trydofor.game.dot.udt;

public class UserConf 
{
	// 游戏设置
	private String  url;
	private boolean proxy;
	private String  proxyHost;
	private int     proxyPort;
	private int     server;
	private int 	world;
	private String  loginId;
	private String  passwd;
	private String  gameId;
	private String  gameName;
	private String[]  attack;
	private String  pkmode;
	private String  notsell;
	private int  	restCityX = 0;
	private int  	restCityY = 0;
	private int     sellPrc = 1000;
	private int     sellBag = 0;
	private int		sleepHp = 0;
	private int     sleepMp = 0;
	private int     repair = 1;
	private int     purify = 300;
	private int[]   mapType = null;
	private boolean mapRandom = true;
	
	private int     loginIdle = 0;
	private int     cityIdle = 0;
	private int     fightIdle = 0;
	private int     attackIdle = 0;
	
	public boolean isMapRandom() {
		return mapRandom;
	}
	public void setMapRandom(boolean mapRandom) {
		this.mapRandom = mapRandom;
	}
	public int[] getMapType() {
		return mapType;
	}
	public void setMapType(int[] mapType) {
		this.mapType = mapType;
	}
	public String[] getAttack() {
		return attack;
	}
	public void setAttack(String[] attack) {
		this.attack = attack;
	}
	public String getGameId() {
		return gameId;
	}
	public void setGameId(String gameId) {
		this.gameId = gameId;
	}
	public String getGameName() {
		return gameName;
	}
	public void setGameName(String gameName) {
		this.gameName = gameName;
	}
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public String getNotsell() {
		return notsell;
	}
	public void setNotsell(String notsell) {
		this.notsell = notsell;
	}
	public String getPasswd() {
		return passwd;
	}
	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}
	public String getPkmode() {
		return pkmode;
	}
	public void setPkmode(String pkmode) {
		this.pkmode = pkmode;
	}
	public boolean isProxy() {
		return proxy;
	}
	public void setProxy(boolean proxy) {
		this.proxy = proxy;
	}
	public String getProxyHost() {
		return proxyHost;
	}
	public void setProxyHost(String proxyHost) {
		this.proxyHost = proxyHost;
	}
	public int getProxyPort() {
		return proxyPort;
	}
	public void setProxyPort(int proxyPort) {
		this.proxyPort = proxyPort;
	}
	public int getServer() {
		return server;
	}
	public void setServer(int server) {
		this.server = server;
	}
	public int getWorld() {
		return world;
	}
	public void setWorld(int world) {
		this.world = world;
	}
	public int getPurify() {
		return purify;
	}
	public void setPurify(int purify) {
		this.purify = purify;
	}
	public int getRepair() {
		return repair;
	}
	public void setRepair(int repair) {
		this.repair = repair;
	}
	public int getSellBag() {
		return sellBag;
	}
	public void setSellBag(int sellBag) {
		this.sellBag = sellBag;
	}

	public int getSleepHp() {
		return sleepHp;
	}
	public void setSleepHp(int sleepHp) {
		this.sleepHp = sleepHp;
	}
	public int getSleepMp() {
		return sleepMp;
	}
	public void setSleepMp(int sleepMp) {
		this.sleepMp = sleepMp;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}

	public int getSellPrc() {
		return sellPrc;
	}
	public void setSellPrc(int sellPrc) {
		this.sellPrc = sellPrc;
	}
	public int getRestCityX() {
		return restCityX;
	}
	public void setRestCityX(int restCityX) {
		this.restCityX = restCityX;
	}
	public int getRestCityY() {
		return restCityY;
	}
	public void setRestCityY(int restCityY) {
		this.restCityY = restCityY;
	}
	public int getAttackIdle() {
		return attackIdle;
	}
	public void setAttackIdle(int attackIdle) {
		this.attackIdle = attackIdle;
	}
	public int getCityIdle() {
		return cityIdle;
	}
	public void setCityIdle(int cityIdle) {
		this.cityIdle = cityIdle;
	}
	public int getFightIdle() {
		return fightIdle;
	}
	public void setFightIdle(int fightIdle) {
		this.fightIdle = fightIdle;
	}
	public int getLoginIdle() {
		return loginIdle;
	}
	public void setLoginIdle(int loginIdle) {
		this.loginIdle = loginIdle;
	}
	
	
}
